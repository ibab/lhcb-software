#ifndef USER_SingleBCandidateSelection_BdDpi_H 
#define USER_SingleBCandidateSelection_BdDpi_H 1

// from Gaudi
#include "Kernel/DaVinciAlgorithm.h"
#include "Kernel/IParticleDescendants.h"
#include "ITaggingUtilsChecker.h"



class IDistanceCalculator;
class DaVinciAlgorithm;
class IPVReFitter;





// from local

/** @class SingleBCandidateSelection_BdDpi SingleBCandidateSelection_BdDpi.h 
 *  
 *  Select events looking for the one candidate with best chi2
 *
 *  @author Stefania Vecchi
 *  @date   09/12/2011
 */

class SingleBCandidateSelection_BdDpi : public DaVinciAlgorithm {

 public: 
  /// Standard constructor
  SingleBCandidateSelection_BdDpi( const std::string& name, ISvcLocator* pSvcLocator );

  virtual ~SingleBCandidateSelection_BdDpi( ); ///< Destructor

  virtual StatusCode initialize();    ///< Algorithm initialization
  virtual StatusCode execute   ();    ///< Algorithm execution
  virtual StatusCode finalize  ();    ///< Algorithm finalization

 private:
  const LHCb::Particle* findID( int id, LHCb::Particle::ConstVector& v, int s, int i);
  
  double get_MINIPCHI2(const LHCb::Particle* p, int opt);
  double get_BPVVDCHI2(const LHCb::Particle* B, const LHCb::Particle* P);
  double get_MIPDV(const LHCb::Particle* p);
  //void get_MIPDV(const LHCb::Particle* p, double MyIP, double MyIPChi2);

  std::string m_inputLocation;
  IParticleDescendants* m_descend;
  ITaggingUtilsChecker* m_util;
  

  
};
//===========================================================================//
#endif // USER_SingleBCandidateSelection_BdDpi_H
