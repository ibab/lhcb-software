// Include files 
#include "SingleBCandidateSelection_BdDpi.h"
// from LHCb core
#include "Event/ODIN.h"

#include "DecayTreeFitter/Fitter.h"
#include "LoKi/Particles36.h"
#include "LoKi/ParticleCuts.h"

//-----------------------------------------------------------------------------
// Implementation file for class : SingleBCandidateSelection_BdDpi
//
// Author: Stefania Vecchi
//-----------------------------------------------------------------------------

using namespace LHCb ;
using namespace Gaudi::Units;
using namespace LoKi::Cuts;


// Declaration of Factory
DECLARE_ALGORITHM_FACTORY( SingleBCandidateSelection_BdDpi );

//=============================================================================
SingleBCandidateSelection_BdDpi::SingleBCandidateSelection_BdDpi(const std::string& name,
                                                                         ISvcLocator* pSvcLocator)
  : DaVinciAlgorithm ( name , pSvcLocator ),
    m_descend(0),
    m_util(0)
{
  declareProperty( "InputLocation",
                   m_inputLocation = "");
}

//=============================================================================
StatusCode SingleBCandidateSelection_BdDpi::execute() {

  setFilterPassed( false );

  debug() << "Getting particles saved in "<<m_inputLocation<< endmsg ;
  
  if(!exist<Particle::Container>(m_inputLocation) &&
     !exist<Particle::Selection>(m_inputLocation) ){
    debug()<<"nosignal found in : "<< m_inputLocation<<endmsg;
    
    return StatusCode::SUCCESS; //unselected
  }
  
  const Particle* AXBS  = 0;
  const Particles* ptmp = get<Particles>( m_inputLocation );
  double minchi2B = 9999;
  int iB=0;
  
  for( Particles::const_iterator ip=ptmp->begin(); ip!=ptmp->end(); ip++){
    if((*ip)->particleID().hasBottom()) {
    iB++;
    
    debug()<<"signal part pt: "<< (*ip)->pt()
           << "  ID: "<< (*ip)->particleID().pid()<<" "<<"candidate "<<iB<<"/"<<ptmp->size()<<endreq;


      ////////////////////////////////////////////////////

      const Particle* Bd = (*ip);
      Particle::ConstVector parts = m_descend->descendants(Bd);

      // B0d (bbar d) -> D-(bar c d) pi+ (u bar d) 
      //                 D-(bar c d) -> K+ pi- pi-
      //std::cout<<" particles in the list: ";

      int sumID=0;
      int sumabsID=0;
      
      for( Particle::ConstVector::const_iterator ip=parts.begin(); ip!=parts.end(); ip++){
        //std::cout<<" "<<(*ip)->particleID().pid();        
        sumabsID +=(*ip)->particleID().abspid();        
        sumID +=(*ip)->particleID().pid();        
      }
      //std::cout<<std::endl;
      if(sumabsID!=411+211+211+321+211) continue;
      if(abs(sumID)!=abs(411+211+211-321-211)) continue;
      

      debug()<<" Pi-1from D"<<endmsg;      
      const Particle* piminus1fD  = findID(211, parts,1,1);//find pion from D
      debug()<<" Pi-2from D"<<endmsg;      
      const Particle* piminus2fD = findID(211, parts,1,2); //find pion from D
      debug()<<" K from D"<<endmsg;      
      const Particle* kaonfD    = findID(-321, parts,1,1); //find pi+ from D
      //const Particle* piplusfD    = findID(-211, parts,1,3); //find pi+ from D
      /*
      const Particle* kaonfD    = findID(-211, parts,1,3); //find pi+ from D

      const int pID=-321*(int)kaonfD->charge();
      std::cout<<" id"<<pID<<" "<<kaonfD->charge()<<std::endl;
      
      kaonfD->setParticleID(ParticleID(pID));
      */

      debug()<<" Pi+from B"<<endmsg;      
      const Particle* piplus    = findID(-211, parts,0,0);//find pi+ from B
      debug()<<" D-from B"<<endmsg;      
      const Particle* Dminus    = findID(411, parts,0,0); //find D-

      if(!Dminus || !piplus || !piminus1fD || !piminus2fD || !kaonfD)  return StatusCode::SUCCESS;
      /*
      Particle *kaonfD = new Particle();
      std::cout<<"Muoio 1"<<std::endl;
      
      kaonfD->setProto(piplusfD->proto());
      std::cout<<"Muoio 2"<<std::endl;
      const int pID=-321*(int)piplusfD->charge();
      std::cout<<" id"<<pID<<" "<<piplusfD->charge()<<std::endl;
      
      kaonfD->setParticleID(ParticleID(pID));
      std::cout<<"Muoio 3"<<std::endl;
      kaonfD->setMeasuredMass(493.677);
      debug()<<" Forced pion- to be a kaon"<<*kaonfD<<endmsg;
      */
      

      //work out physical variables

      double kaonfD_TRACK_Type    = kaonfD->proto()->track()->type();
      double kaonfD_TRACK_CHI2NDOF= kaonfD->proto()->track()->chi2()/kaonfD->proto()->track()->nDoF();
      double kaonfD_MINIPCHI2     = get_MINIPCHI2(kaonfD,0);
      double kaonfD_P    = kaonfD->p();
      double kaonfD_M    = 493.677;
      double kaonfD_E    = sqrt(kaonfD_P*kaonfD_P + kaonfD_M*kaonfD_M);
      double kaonfD_PT   = kaonfD->pt();
      double kaonfD_PIDK = kaonfD->proto()->info(LHCb::ProtoParticle::CombDLLk,-1000);
      double kaonfD_PIDp = kaonfD->proto()->info(LHCb::ProtoParticle::CombDLLp,-1000);

      double piminus1fD_TRACK_Type    = piminus1fD->proto()->track()->type();
      double piminus1fD_TRACK_CHI2NDOF= piminus1fD->proto()->track()->chi2()/piminus1fD->proto()->track()->nDoF();
      double piminus1fD_MINIPCHI2     = get_MINIPCHI2(piminus1fD,0);
      double piminus1fD_P    = piminus1fD->p();
      double piminus1fD_M    = 139.57018;
      double piminus1fD_E    = sqrt(piminus1fD_P*piminus1fD_P + piminus1fD_M*piminus1fD_M);
      double piminus1fD_PT   = piminus1fD->pt();
      double piminus1fD_PIDK = piminus1fD->proto()->info(LHCb::ProtoParticle::CombDLLk,-1000);
      double piminus1fD_PIDp = piminus1fD->proto()->info(LHCb::ProtoParticle::CombDLLp,-1000);

      double piminus2fD_TRACK_Type    = piminus2fD->proto()->track()->type();
      double piminus2fD_TRACK_CHI2NDOF= piminus2fD->proto()->track()->chi2()/piminus2fD->proto()->track()->nDoF();
      double piminus2fD_MINIPCHI2     = get_MINIPCHI2(piminus2fD,0);
      double piminus2fD_P    = piminus2fD->p();
      double piminus2fD_M    = 139.57018;
      double piminus2fD_E    = sqrt(piminus2fD_P*piminus2fD_P + piminus2fD_M*piminus2fD_M);
      double piminus2fD_PT   = piminus2fD->pt();
      double piminus2fD_PIDK = piminus2fD->proto()->info(LHCb::ProtoParticle::CombDLLk,-1000);
      double piminus2fD_PIDp = piminus2fD->proto()->info(LHCb::ProtoParticle::CombDLLp,-1000);

      double maxIPchi2 = 0;      
      if (maxIPchi2 < kaonfD_MINIPCHI2 ) maxIPchi2 =  kaonfD_MINIPCHI2;
      if( maxIPchi2 < piminus1fD_MINIPCHI2) maxIPchi2 = piminus1fD_MINIPCHI2;
      if( maxIPchi2 < piminus2fD_MINIPCHI2)  maxIPchi2 = piminus2fD_MINIPCHI2;


      double piplus_TRACK_Type    = piplus->proto()->track()->type();
      double piplus_TRACK_CHI2NDOF= piplus->proto()->track()->chi2()/piplus->proto()->track()->nDoF();
      double piplus_MINIPCHI2     = get_MINIPCHI2(piplus,0);
      double piplus_P    = piplus->p();
      double piplus_PT   = piplus->pt();
      double piplus_PIDK = piplus->proto()->info(LHCb::ProtoParticle::CombDLLk,-1000);
      double piplus_PIDp = piplus->proto()->info(LHCb::ProtoParticle::CombDLLp,-1000);

      double Dminus_MM = Dminus->measuredMass();
      double Dminus_MMerr = Dminus->measuredMassErr();
      double Dminus_PT = Dminus->pt();
      double Dminus_P = Dminus->p();
      double Dminus_E = sqrt(Dminus_P*Dminus_P + Dminus_MM*Dminus_MM);
      double Dminus_ENDVERTEX_CHI2 = Dminus->endVertex()->chi2();
      double Dminus_ENDVERTEX_NDOF = Dminus->endVertex()->nDoF();
      double Dminus_MINIPCHI2     = get_MINIPCHI2(Dminus,0);      

      double Bd_MM  = Bd->measuredMass();
      double Bd_P   = Bd->p();
      double Bd_PT  = Bd->pt();
      double Bd_ENDVERTEX_CHI2 = Bd->endVertex()->chi2();
      double Bd_ENDVERTEX_NDOF = Bd->endVertex()->nDoF();
      double Bd_ENDVERTEX_Z    = Bd->endVertex()->position().z();
      double Bd_MINIPCHI2 = get_MINIPCHI2(Bd,0);
      double Bd_MINIPCHI2NEXTBEST = get_MINIPCHI2(Bd,1);


      int nPV = (int) get_MINIPCHI2(Bd,2); // see the function below


 
  
      const VertexBase* aPV = bestPV( Bd );
      if( !aPV )return StatusCode::FAILURE;
      double Bd_OWNPV_Z = aPV->position().z();

      const Vertex* evtx = Bd->endVertex();
      if( !evtx ) return StatusCode::FAILURE;

      Gaudi::XYZVector A = Bd->momentum().Vect();
      Gaudi::XYZVector B = evtx->position() - aPV->position();  
      double cosPFD = A.Dot( B ) / std::sqrt( A.Mag2()*B.Mag2() );
      double Bd_cosDIRA = cosPFD;

      // flight distance
      double dist = 0;
      double chi2 = 0 ;
      StatusCode sc =  distanceCalculator()->distance( aPV, evtx, dist, chi2 );
      if (!sc) return sc ;
      double Bd_FDs = sqrt(chi2);
      debug()<<" Bd_FDs="<<  Bd_FDs <<"  Bd_cosDIRA="<<Bd_cosDIRA <<endmsg;
      

      const Vertex* evtxD = Dminus->endVertex();
      if( !evtxD ) return StatusCode::FAILURE;
      Gaudi::XYZVector AD = Dminus->momentum().Vect();
      Gaudi::XYZVector BD = evtxD->position() - aPV->position();  
      cosPFD = AD.Dot( BD ) / std::sqrt( AD.Mag2()*BD.Mag2() );
      double Dminus_cosDIRA = cosPFD;

      // flight distance
      dist = 0;
      chi2 = 0 ;
      sc =  distanceCalculator()->distance( aPV, evtxD, dist, chi2 );
      if (!sc) return sc ;
      double Dminus_FDs = sqrt(chi2);

      debug()<<" Dminus_FDs="<<Dminus_FDs<<" Dminus_cosDIRA="<<Dminus_cosDIRA<<endmsg;
      

      debug()<<"Start DecayVertexFitter"<<endmsg;

      const DTF_CHI2NDOF fun = DTF_CHI2NDOF(true,"D-");
      const double DTF_chi2ndof = fun(Bd);

      const DTF_CTAU fun_tau = DTF_CTAU(0, true);
      const double DTF_tau = fun_tau(Bd);

      const DTF_CTAUERR fun_tau_err = DTF_CTAUERR(0, true);
      const double DTF_tau_err = fun_tau_err(Bd);

      
      const DTF_FUN fun2 = DTF_FUN(M, true,"D-");
      const double DTF_Bmass = fun2(Bd);

      debug()<<"DTF_chi2 "<<DTF_chi2ndof<<" DTF_Bmass=  "<<DTF_Bmass<<"   "<<" DTF_tau="<<DTF_tau<<endmsg;
      

      ////////////////////////////////////////////////////
      //      put here your selection cuts              //
      ////////////////////////////////////////////////////

      bool Strip12 = false;

      LHCb::ODIN* odin(0);

      
      if( exist<ODIN>( LHCb::ODINLocation::Default ) ){
        odin = get<ODIN>( LHCb::ODINLocation::Default );
      }
      
      if(
         // cuts on D daughters
         kaonfD_TRACK_CHI2NDOF<5 && piminus1fD_TRACK_CHI2NDOF < 5 && piminus2fD_TRACK_CHI2NDOF < 5 //track chi2
         && kaonfD_P >  2000*MeV && piminus1fD_P  > 2000*MeV && piminus2fD_P  > 2000*MeV  // momentum
         && kaonfD_PT > 300*MeV && piminus1fD_PT > 300*MeV && piminus2fD_PT > 300*MeV  // transverse momentum
         && kaonfD_MINIPCHI2 > 9 && piminus1fD_MINIPCHI2 > 9 && piminus2fD_MINIPCHI2 >9 // IPchi2
         && maxIPchi2>40
         && kaonfD_PIDK > 0 && piminus1fD_PIDK<5 && piminus2fD_PIDK<5 // PID cuts 

         // cuts on the bachelor pi
         && piplus_TRACK_CHI2NDOF<5 // track chi2
         && piplus_P > 5000*MeV     //momentum
         && piplus_PT > 500*MeV // transverse momentum
         && piplus_MINIPCHI2 > 16   // IP chi2
         && piplus_PIDK < 5 // PID cuts

         // cuts on the D candidate
         && Dminus_P > 2000*MeV // momentum
         && Dminus_PT > 2000*MeV // transverse momentum
         && Dminus_ENDVERTEX_CHI2/Dminus_ENDVERTEX_NDOF <12 // chi2 vertex fit
         && Dminus_MINIPCHI2 > 9 // IP chi2
         && fabs( Dminus_MM - 1869.60*MeV) < 30. //ok
         && Dminus_cosDIRA > 0.9 // DIRA
         && Dminus_FDs > 10 // flight distance significance

         // cuts on the B candidate
         //&& Bd_P > 2000*MeV// momentum
         && Bd_ENDVERTEX_CHI2/Bd_ENDVERTEX_NDOF <12 //vertex chi2
         && Bd_MINIPCHI2 < 16
         && DTF_tau > 0.2 // decay time
         && Bd_cosDIRA > 0.9999 // DIRA 
         && Bd_FDs > 8 // Flight distance significance
         //&& Bd_MM  > 5200 && Bd_MM  < 5500.
         && fabs(Bd_MM - 5279.50 ) < 500.
         && DTF_chi2ndof < 10

         ) Strip12 = true ;

      if(!Strip12) {
        debug()<<" B cuts failed "<<endmsg;
        continue;
      }
      
      //double chi2 = (*ip)->endVertex()->chi2PerDoF();
      chi2 = DTF_chi2ndof;
      if(minchi2B > chi2) {
        minchi2B = chi2;
        AXBS = (*ip);
      }
      
    }
    
    
  }
  
  
  
    
  if(!AXBS) return StatusCode::SUCCESS; //unselected


  //save to tes//////////////////////////////////////////////////
  Particle::ConstVector axdaughter(0);
  axdaughter.push_back(AXBS);
  debug()<<"Going to save this B hypo to TES  "<<endreq;
  this->cloneAndMarkTrees(axdaughter);

/* // Commentato
  debug()<<"Going to save this B hypo to TES  "<<endreq;
  StatusCode sc1 = desktop()->cloneTrees(axdaughter);
  if (sc1.isFailure()) {
    warning() << "Unable to clone Tree to TES" << endreq;
    return StatusCode::SUCCESS;
  }
*/
//   StatusCode sc2 = desktop()->saveTrees(axdaughter);
//   if (sc2.isFailure()) {
//     warning() << "Unable to save Tree to TES" << endreq;
//     return StatusCode::SUCCESS;
//   }

  setFilterPassed( true );
  return StatusCode::SUCCESS;
}

//=============================================================================
const Particle* SingleBCandidateSelection_BdDpi::findID(int id, 
                                                        Particle::ConstVector& v,
                                                        int opts, int inum ){
  int isel=0;  
  const Particle* p = 0;
  debug() <<"searching for signal id: "<<id<<" particle list: "<<v.size()<<" opt="<<opts<<endmsg;
  
  for( Particle::ConstVector::const_iterator ip=v.begin(); ip!=v.end(); ip++){
    if( opts== 1 ){
      if( abs(id)==211 && (*ip)->particleID().abspid() == abs(id) ) {
          debug()<<" Found particle "<<(*ip)->particleID().pid()<<endmsg;      
        const Particle* mater = m_util->motherof(*ip, v);
        if(mater) {
          debug()<<" ----> mother "<<mater->particleID().abspid()<<endmsg;          
          if( mater->particleID().abspid()!=411) continue;
          isel++;
          debug()<<" isel "<<isel<<" inum "<<inum<<endmsg;          
          if(isel<inum) continue;        
          p = (*ip);
          debug()<<" Found particle "<<*p<<" from mother "<< mater->particleID().abspid()<<endmsg;      
          return p;        
          break;
        }
        
      } else if( abs(id) == 321 && (*ip)->particleID().abspid() == abs(id) ) {
        const Particle* mater = m_util->motherof(*ip, v);
        if(mater) {
          if(mater->particleID().abspid()!=411) continue;      
          p = (*ip);
          debug()<<" Found particle "<<*p<<" from mother "<< mater->particleID().abspid()<<endmsg;
          return p;        
          break;
        }        
      }
    } else if( opts== 0 ) {
      if( (abs(id)==211 || abs(id)==411) && (*ip)->particleID().abspid() == abs(id) ) {
        const Particle* mater = m_util->motherof(*ip, v);
        if(mater) continue;
        p = (*ip);
        debug()<<" Found particle "<<*p<<" from mother B"<<endmsg;
        return p;        
        break;
      } else if( (*ip)->particleID().abspid() == 511 ) {
        p = (*ip);
        debug()<<" Found particle "<<*p<<endmsg;
        return p;        
        break;
      }      
    } else { debug()<<" missed the right option "<< id<<" "<<opts<<endmsg;
    }
  }
  
  if(!p) {
    err()<<"particle not found id: "<<id<<endreq;
    return NULL;
  } 


  return p;

}

//=============================================================================
/* double SingleBCandidateSelection_BdDpi::get_MINIPCHI2(const Particle* p, int opt){  
  double minchi2 = -1 ;
  double minchi2nextbest = -1;

  const RecVertex::Range PV = primaryVertices();
  if ( !PV.empty() ){
    for (RecVertex::Range::const_iterator pv = PV.begin(); pv!=PV.end(); ++pv){
      double ip, chi2;
      StatusCode test2 = distanceCalculator()->distance ( p, *pv, ip, chi2 );
      if( test2 ) {
        if ((chi2<minchi2) || (minchi2<0.)) {
          minchi2nextbest = minchi2 ;        
          minchi2 = chi2 ;     
        } else {
          if((chi2 < minchi2nextbest) || (minchi2nextbest < 0)) {
            minchi2nextbest = chi2;
          }
        }        
      }
    }
  }
  if(opt==0) return minchi2;
  else if(opt==1) return minchi2nextbest;
  else if(opt==2) return PV.size();
  else return -999;
  
}
*/


 double SingleBCandidateSelection_BdDpi::get_MINIPCHI2(const Particle* p, int opt){  
  double minchi2 = -1 ;
  double minchi2nextbest = -1;

  const RecVertex::Range PV = primaryVertices();

  IPVReFitter* m_pvReFitter = tool<IPVReFitter>("AdaptivePVReFitter", this );
  

  if ( !PV.empty() ){
    for (RecVertex::Range::const_iterator pv = PV.begin(); pv!=PV.end(); ++pv){
      
      RecVertex newPV(**pv);
      // refit PV (remove B signal tracks)
      StatusCode scfit = m_pvReFitter->remove(p, &newPV);
      if(!scfit) {
        Warning("ReFitter fails!",StatusCode::SUCCESS,10).ignore();
        continue;
      }

      double chi2;      
      double ip;
      
      LHCb::VertexBase* newPVPtr = (LHCb::VertexBase*)&newPV;
      StatusCode test2 = distanceCalculator()->distance ( p, newPVPtr, ip, chi2 );
      if( test2 ) {
        if ((chi2<minchi2) || (minchi2<0.))
        { 
          minchi2nextbest = minchi2; 
          minchi2 = chi2 ;
        }
        else
        { 
          if((chi2 < minchi2nextbest) || (minchi2nextbest < 0))
          {            
            minchi2nextbest = chi2; 
          }
        }
      }
    }
  }
  if(opt==0) return minchi2;
  else if(opt==1) return minchi2nextbest;
  else if(opt==2) return PV.size();
  else return -999;
 }


//========================================================================
double SingleBCandidateSelection_BdDpi::get_MIPDV(const Particle* p){
  
  double minip = -1;
  const RecVertex::Range PV = primaryVertices();
  if ( !PV.empty() ){
    for (RecVertex::Range::const_iterator pv = PV.begin(); pv!=PV.end(); ++pv){
      double ip, chi2;
      StatusCode test = distanceCalculator()->distance ( p, *pv, ip, chi2 );
      if( test ){  
        if( ip<minip || minip<0.) minip = ip ;//sara
      }			
    }	
  }  return minip; 
}

//=============================================================================
double SingleBCandidateSelection_BdDpi::get_BPVVDCHI2(const Particle* B,
                                                          const Particle* P){
  const VertexBase* rV = getRelatedPV(B);

  double chi2 = 0 ;
  if ( 0==rV ){
    chi2 = -999. ;
  } else {
   // flight distance
    double dist = 0;
    StatusCode sc = distanceCalculator()->distance( rV, P->endVertex(), dist, chi2 );
    if (!sc) return -999.;
  }
  return chi2 ;
}


//=============================================================================
StatusCode SingleBCandidateSelection_BdDpi::initialize() {

  m_descend = tool<IParticleDescendants> ( "ParticleDescendants", this );
  if( ! m_descend ) {
    fatal() << "Unable to retrieve ParticleDescendants tool "<< endreq;
    return StatusCode::FAILURE;
  }
 
  m_util = tool<ITaggingUtilsChecker> ( "TaggingUtilsChecker", this );
  if( ! m_util ) {
    fatal() << "Unable to retrieve TaggingUtilsChecker tool "<< endreq;
    return StatusCode::FAILURE;
  }
 
  return DaVinciAlgorithm::initialize() ;
}
//=============================================================================
StatusCode SingleBCandidateSelection_BdDpi::finalize() {
  return DaVinciAlgorithm::finalize();
}
//=============================================================================
SingleBCandidateSelection_BdDpi::~SingleBCandidateSelection_BdDpi() {};

