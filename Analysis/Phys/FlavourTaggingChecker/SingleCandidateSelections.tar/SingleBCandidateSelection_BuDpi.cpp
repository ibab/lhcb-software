// Include files 
#include "SingleBCandidateSelection_BuDpi.h"
// from LHCb core
#include "Event/ODIN.h"

#include "DecayTreeFitter/Fitter.h"
#include "LoKi/Particles36.h"
#include "LoKi/ParticleCuts.h"

//-----------------------------------------------------------------------------
// Implementation file for class : SingleBCandidateSelection_BuDpi
//
// Author: Stefania Vecchi
//-----------------------------------------------------------------------------

using namespace LHCb ;
using namespace Gaudi::Units;
using namespace LoKi::Cuts;


// Declaration of Factory
DECLARE_ALGORITHM_FACTORY( SingleBCandidateSelection_BuDpi );

//=============================================================================
SingleBCandidateSelection_BuDpi::SingleBCandidateSelection_BuDpi(const std::string& name,
                                                                         ISvcLocator* pSvcLocator)
  : DaVinciAlgorithm ( name , pSvcLocator ),
    m_descend(0),
    m_util(0)
{
  declareProperty( "InputLocation",
                   m_inputLocation = "");
}

//=============================================================================
StatusCode SingleBCandidateSelection_BuDpi::execute() {

  setFilterPassed( false );

  debug() << "Getting particles saved in "<<m_inputLocation<< endmsg ;
  
  if(!exist<Particle::Container>(m_inputLocation) &&
     !exist<Particle::Selection>(m_inputLocation) ){
    debug()<<"nosignal found in : "<< m_inputLocation<<endmsg;
    
    return StatusCode::SUCCESS; //unselected
  }
  
  const Particle* AXBS  = 0;
  const Particles* ptmp = get<Particles>( m_inputLocation );
  double minchi2B = 9999;
  int iB=0;
  
  for( Particles::const_iterator ip=ptmp->begin(); ip!=ptmp->end(); ip++){
    if((*ip)->particleID().hasBottom()) {
    iB++;
    
    debug()<<"signal part pt: "<< (*ip)->pt()
           << "  ID: "<< (*ip)->particleID().pid()<<" "<<"candidate "<<iB<<"/"<<ptmp->size()<<endreq;


      ////////////////////////////////////////////////////

      const Particle* Bu = (*ip);
      Particle::ConstVector parts = m_descend->descendants(Bu);

      // B+:  B0u (bbar u) -> barD0(bar c u) pi+ (u bar d) 
      //                      barD0(bar c u) -> K+ pi-
      //std::cout<<" particles in the list: ";

      int sumID=0;
      int sumabsID=0;
      
      for( Particle::ConstVector::const_iterator ip=parts.begin(); ip!=parts.end(); ip++){
        //std::cout<<" "<<(*ip)->particleID().pid();        
        sumabsID +=(*ip)->particleID().abspid();        
        sumID +=(*ip)->particleID().pid();        
      }
      //std::cout<<std::endl;
      if(sumabsID!=421+211+321+211) continue;
      if(abs(sumID)!=abs(-421+211+321-211)) continue;
      

      debug()<<" Pi- from D0"<<endmsg;      
      const Particle* piminusfD  = findID(-211, parts,1,1);//find pion from D
      debug()<<" K+ from D0"<<endmsg;      
      const Particle* kaonfD    = findID(321, parts,1,1); //find pi+ from D

      debug()<<" Pi+ from B"<<endmsg;      
      const Particle* piplus    = findID(211, parts,0,0);//find pi+ from B
      debug()<<" D0 from B"<<endmsg;      
      const Particle* Dzero    = findID(-421, parts,0,0); //find D0

      if(!Dzero || !piplus || !piminusfD || !kaonfD)  return StatusCode::SUCCESS;
      //work out physical variables

      double kaonfD_TRACK_Type    = kaonfD->proto()->track()->type();
      double kaonfD_TRACK_CHI2NDOF= kaonfD->proto()->track()->chi2()/kaonfD->proto()->track()->nDoF();
      double kaonfD_MINIPCHI2     = get_MINIPCHI2(kaonfD,0);
      double kaonfD_P    = kaonfD->p();
      double kaonfD_M    = 493.677;
      double kaonfD_E    = sqrt(kaonfD_P*kaonfD_P + kaonfD_M*kaonfD_M);
      double kaonfD_PT   = kaonfD->pt();
      double kaonfD_PIDK = kaonfD->proto()->info(LHCb::ProtoParticle::CombDLLk,-1000);
      double kaonfD_PIDp = kaonfD->proto()->info(LHCb::ProtoParticle::CombDLLp,-1000);

      double piminusfD_TRACK_Type    = piminusfD->proto()->track()->type();
      double piminusfD_TRACK_CHI2NDOF= piminusfD->proto()->track()->chi2()/piminusfD->proto()->track()->nDoF();
      double piminusfD_MINIPCHI2     = get_MINIPCHI2(piminusfD,0);
      double piminusfD_P    = piminusfD->p();
      double piminusfD_M    = 139.57018;
      double piminusfD_E    = sqrt(piminusfD_P*piminusfD_P + piminusfD_M*piminusfD_M);
      double piminusfD_PT   = piminusfD->pt();
      double piminusfD_PIDK = piminusfD->proto()->info(LHCb::ProtoParticle::CombDLLk,-1000);
      double piminusfD_PIDp = piminusfD->proto()->info(LHCb::ProtoParticle::CombDLLp,-1000);


      double maxIPchi2 = 0;      
      if (maxIPchi2 < kaonfD_MINIPCHI2 ) maxIPchi2 =  kaonfD_MINIPCHI2;
      if( maxIPchi2 < piminusfD_MINIPCHI2) maxIPchi2 = piminusfD_MINIPCHI2;


      double piplus_TRACK_Type    = piplus->proto()->track()->type();
      double piplus_TRACK_CHI2NDOF= piplus->proto()->track()->chi2()/piplus->proto()->track()->nDoF();
      double piplus_MINIPCHI2     = get_MINIPCHI2(piplus,0);
      double piplus_P    = piplus->p();
      double piplus_PT   = piplus->pt();
      double piplus_PIDK = piplus->proto()->info(LHCb::ProtoParticle::CombDLLk,-1000);
      double piplus_PIDp = piplus->proto()->info(LHCb::ProtoParticle::CombDLLp,-1000);

      double Dzero_MM = Dzero->measuredMass();
      double Dzero_MMerr = Dzero->measuredMassErr();
      double Dzero_PT = Dzero->pt();
      double Dzero_P = Dzero->p();
      double Dzero_E = sqrt(Dzero_P*Dzero_P + Dzero_MM*Dzero_MM);
      double Dzero_ENDVERTEX_CHI2 = Dzero->endVertex()->chi2();
      double Dzero_ENDVERTEX_NDOF = Dzero->endVertex()->nDoF();
      double Dzero_MINIPCHI2     = get_MINIPCHI2(Dzero,0);      

      double Bu_MM  = Bu->measuredMass();
      double Bu_P   = Bu->p();
      double Bu_PT  = Bu->pt();
      double Bu_ENDVERTEX_CHI2 = Bu->endVertex()->chi2();
      double Bu_ENDVERTEX_NDOF = Bu->endVertex()->nDoF();
      double Bu_ENDVERTEX_Z    = Bu->endVertex()->position().z();
      double Bu_MINIPCHI2 = get_MINIPCHI2(Bu,0);
      double Bu_MINIPCHI2NEXTBEST = get_MINIPCHI2(Bu,1);


      int nPV = (int) get_MINIPCHI2(Bu,2); // see the function below


 
  
      const VertexBase* aPV = bestPV( Bu );
      if( !aPV )return StatusCode::FAILURE;
      double Bu_OWNPV_Z = aPV->position().z();

      const Vertex* evtx = Bu->endVertex();
      if( !evtx ) return StatusCode::FAILURE;

      Gaudi::XYZVector A = Bu->momentum().Vect();
      Gaudi::XYZVector B = evtx->position() - aPV->position();  
      double cosPFD = A.Dot( B ) / std::sqrt( A.Mag2()*B.Mag2() );
      double Bu_cosDIRA = cosPFD;

      // flight distance
      double dist = 0;
      double chi2 = 0 ;
      StatusCode sc =  distanceCalculator()->distance( aPV, evtx, dist, chi2 );
      if (!sc) return sc ;
      double Bu_FDs = sqrt(chi2);
      debug()<<" Bu_FDs="<<  Bu_FDs <<"  Bu_cosDIRA="<<Bu_cosDIRA <<endmsg;
      

      const Vertex* evtxD = Dzero->endVertex();
      if( !evtxD ) return StatusCode::FAILURE;
      Gaudi::XYZVector AD = Dzero->momentum().Vect();
      Gaudi::XYZVector BD = evtxD->position() - aPV->position();  
      cosPFD = AD.Dot( BD ) / std::sqrt( AD.Mag2()*BD.Mag2() );
      double Dzero_cosDIRA = cosPFD;

      // flight distance
      dist = 0;
      chi2 = 0 ;
      sc =  distanceCalculator()->distance( aPV, evtxD, dist, chi2 );
      if (!sc) return sc ;
      double Dzero_FDs = sqrt(chi2);

      debug()<<" Dzero_FDs="<<Dzero_FDs<<" Dzero_cosDIRA="<<Dzero_cosDIRA<<endmsg;
      

      debug()<<"Start DecayVertexFitter"<<endmsg;

      const DTF_CHI2NDOF fun = DTF_CHI2NDOF(true,"D-");
      const double DTF_chi2ndof = fun(Bu);

      const DTF_CTAU fun_tau = DTF_CTAU(0, true);
      const double DTF_tau = fun_tau(Bu);

      const DTF_CTAUERR fun_tau_err = DTF_CTAUERR(0, true);
      const double DTF_tau_err = fun_tau_err(Bu);

      
      const DTF_FUN fun2 = DTF_FUN(M, true,"D-");
      const double DTF_Bmass = fun2(Bu);

      debug()<<"DTF_chi2 "<<DTF_chi2ndof<<" DTF_Bmass=  "<<DTF_Bmass<<"   "<<" DTF_tau="<<DTF_tau<<endmsg;
      

      ////////////////////////////////////////////////////
      //      put here your selection cuts              //
      ////////////////////////////////////////////////////

      bool Strip12 = false;

      LHCb::ODIN* odin(0);

      
      if( exist<ODIN>( LHCb::ODINLocation::Default ) ){
        odin = get<ODIN>( LHCb::ODINLocation::Default );
      }
      
      if(
         // cuts on D daughters
         kaonfD_TRACK_CHI2NDOF<5 && piminusfD_TRACK_CHI2NDOF < 5 // track chi2
         && kaonfD_P >  2000*MeV && piminusfD_P  > 2000*MeV   // momentum
         && kaonfD_PT > 300*MeV && piminusfD_PT > 300*MeV // transverse momentum
         && kaonfD_MINIPCHI2 > 9 && piminusfD_MINIPCHI2 > 9 // IPchi2
         && maxIPchi2>40
         && kaonfD_PIDK > 0 && piminusfD_PIDK<5  // PID cuts 

         // cuts on the bachelor pi
         && piplus_TRACK_CHI2NDOF<5 // track chi2
         && piplus_P > 5000*MeV     //momentum
         && piplus_PT > 500*MeV // transverse momentum
         && piplus_MINIPCHI2 > 16   // IP chi2
         && piplus_PIDK < 5 // PID cuts

         // cuts on the D candidate
         && Dzero_P > 2000*MeV // momentum
         && Dzero_PT > 2000*MeV // transverse momentum
         && Dzero_ENDVERTEX_CHI2/Dzero_ENDVERTEX_NDOF <12 // chi2 vertex fit
         && Dzero_MINIPCHI2 > 9 // IP chi2
         && fabs( Dzero_MM - 1864.83*MeV) < 30. //ok
         && Dzero_cosDIRA > 0.9 // DIRA
         && Dzero_FDs > 10 // flight distance significance

         // cuts on the B candidate
         //&& Bu_P > 2000*MeV// momentum
         && Bu_ENDVERTEX_CHI2/Bu_ENDVERTEX_NDOF <12 //vertex chi2
         && Bu_MINIPCHI2 < 16
         && DTF_tau > 0.2 // decay time
         && Bu_cosDIRA > 0.9998 // DIRA 
         && Bu_FDs > 8 // Flight distance significance
         //&& Bu_MM  > 5200 && Bu_MM  < 5500.
         && fabs(Bu_MM - 5279.17 ) < 500. // ok
         && DTF_chi2ndof < 10

         ) Strip12 = true ;

      if(!Strip12) {
        debug()<<" B cuts failed "<<endmsg;
        continue;
      }
      
      //double chi2 = (*ip)->endVertex()->chi2PerDoF();
      chi2 = DTF_chi2ndof;
      if(minchi2B > chi2) {
        minchi2B = chi2;
        AXBS = (*ip);
      }
      
    }
    
    
  }
  
  
  
    
  if(!AXBS) return StatusCode::SUCCESS; //unselected


  //save to tes//////////////////////////////////////////////////
  Particle::ConstVector axdaughter(0);
  axdaughter.push_back(AXBS);
  debug()<<"Going to save this B hypo to TES  "<<endreq;
  this->cloneAndMarkTrees(axdaughter);

/* // Commentato
  debug()<<"Going to save this B hypo to TES  "<<endreq;
  StatusCode sc1 = desktop()->cloneTrees(axdaughter);
  if (sc1.isFailure()) {
    warning() << "Unable to clone Tree to TES" << endreq;
    return StatusCode::SUCCESS;
  }
*/
//   StatusCode sc2 = desktop()->saveTrees(axdaughter);
//   if (sc2.isFailure()) {
//     warning() << "Unable to save Tree to TES" << endreq;
//     return StatusCode::SUCCESS;
//   }

  setFilterPassed( true );
  return StatusCode::SUCCESS;
}

//=============================================================================
const Particle* SingleBCandidateSelection_BuDpi::findID(int id, 
                                                        Particle::ConstVector& v,
                                                        int opts, int inum ){
  int isel=0;  
  const Particle* p = 0;
  debug() <<"searching for signal id: "<<id<<" particle list: "<<v.size()<<" opt="<<opts<<endmsg;
  
  for( Particle::ConstVector::const_iterator ip=v.begin(); ip!=v.end(); ip++){
    if( opts== 1 ){
      if( abs(id)==211 && (*ip)->particleID().abspid() == abs(id) ) {
          debug()<<" Found particle "<<(*ip)->particleID().pid()<<endmsg;      
        const Particle* mater = m_util->motherof(*ip, v);
        if(mater) {
          debug()<<" ----> mother "<<mater->particleID().abspid()<<endmsg;          
          if( mater->particleID().abspid()!=421) continue;
          isel++;
          debug()<<" isel "<<isel<<" inum "<<inum<<endmsg;          
          if(isel<inum) continue;        
          p = (*ip);
          debug()<<" Found particle "<<*p<<" from mother "<< mater->particleID().abspid()<<endmsg;      
          return p;        
          break;
        }
        
      } else if( abs(id) == 321 && (*ip)->particleID().abspid() == abs(id) ) {
        const Particle* mater = m_util->motherof(*ip, v);
        if(mater) {
          if(mater->particleID().abspid()!=421) continue;      
          p = (*ip);
          debug()<<" Found particle "<<*p<<" from mother "<< mater->particleID().abspid()<<endmsg;
          return p;        
          break;
        }        
      }
    } else if( opts== 0 ) {
      if( (abs(id)==211 || abs(id)==421) && (*ip)->particleID().abspid() == abs(id) ) {
        const Particle* mater = m_util->motherof(*ip, v);
        if(mater) continue;
        p = (*ip);
        debug()<<" Found particle "<<*p<<" from mother B"<<endmsg;
        return p;        
        break;
      } else if( (*ip)->particleID().abspid() == 511 ) {
        p = (*ip);
        debug()<<" Found particle "<<*p<<endmsg;
        return p;        
        break;
      }      
    } else { debug()<<" missed the right option "<< id<<" "<<opts<<endmsg;
    }
  }
  
  if(!p) {
    err()<<"particle not found id: "<<id<<endreq;
    return NULL;
  } 


  return p;

}

//=============================================================================
/* double SingleBCandidateSelection_BuDpi::get_MINIPCHI2(const Particle* p, int opt){  
  double minchi2 = -1 ;
  double minchi2nextbest = -1;

  const RecVertex::Range PV = primaryVertices();
  if ( !PV.empty() ){
    for (RecVertex::Range::const_iterator pv = PV.begin(); pv!=PV.end(); ++pv){
      double ip, chi2;
      StatusCode test2 = distanceCalculator()->distance ( p, *pv, ip, chi2 );
      if( test2 ) {
        if ((chi2<minchi2) || (minchi2<0.)) {
          minchi2nextbest = minchi2 ;        
          minchi2 = chi2 ;     
        } else {
          if((chi2 < minchi2nextbest) || (minchi2nextbest < 0)) {
            minchi2nextbest = chi2;
          }
        }        
      }
    }
  }
  if(opt==0) return minchi2;
  else if(opt==1) return minchi2nextbest;
  else if(opt==2) return PV.size();
  else return -999;
  
}
*/


 double SingleBCandidateSelection_BuDpi::get_MINIPCHI2(const Particle* p, int opt){  
  double minchi2 = -1 ;
  double minchi2nextbest = -1;

  const RecVertex::Range PV = primaryVertices();

  IPVReFitter* m_pvReFitter = tool<IPVReFitter>("AdaptivePVReFitter", this );
  

  if ( !PV.empty() ){
    for (RecVertex::Range::const_iterator pv = PV.begin(); pv!=PV.end(); ++pv){
      
      RecVertex newPV(**pv);
      // refit PV (remove B signal tracks)
      StatusCode scfit = m_pvReFitter->remove(p, &newPV);
      if(!scfit) {
        Warning("ReFitter fails!",StatusCode::SUCCESS,10).ignore();
        continue;
      }

      double chi2;      
      double ip;
      
      LHCb::VertexBase* newPVPtr = (LHCb::VertexBase*)&newPV;
      StatusCode test2 = distanceCalculator()->distance ( p, newPVPtr, ip, chi2 );
      if( test2 ) {
        if ((chi2<minchi2) || (minchi2<0.))
        { 
          minchi2nextbest = minchi2; 
          minchi2 = chi2 ;
        }
        else
        { 
          if((chi2 < minchi2nextbest) || (minchi2nextbest < 0))
          {            
            minchi2nextbest = chi2; 
          }
        }
      }
    }
  }
  if(opt==0) return minchi2;
  else if(opt==1) return minchi2nextbest;
  else if(opt==2) return PV.size();
  else return -999;
 }


//========================================================================
double SingleBCandidateSelection_BuDpi::get_MIPDV(const Particle* p){
  
  double minip = -1;
  const RecVertex::Range PV = primaryVertices();
  if ( !PV.empty() ){
    for (RecVertex::Range::const_iterator pv = PV.begin(); pv!=PV.end(); ++pv){
      double ip, chi2;
      StatusCode test = distanceCalculator()->distance ( p, *pv, ip, chi2 );
      if( test ){  
        if( ip<minip || minip<0.) minip = ip ;//sara
      }			
    }	
  }  return minip; 
}

//=============================================================================
double SingleBCandidateSelection_BuDpi::get_BPVVDCHI2(const Particle* B,
                                                          const Particle* P){
  const VertexBase* rV = getRelatedPV(B);

  double chi2 = 0 ;
  if ( 0==rV ){
    chi2 = -999. ;
  } else {
   // flight distance
    double dist = 0;
    StatusCode sc = distanceCalculator()->distance( rV, P->endVertex(), dist, chi2 );
    if (!sc) return -999.;
  }
  return chi2 ;
}


//=============================================================================
StatusCode SingleBCandidateSelection_BuDpi::initialize() {

  m_descend = tool<IParticleDescendants> ( "ParticleDescendants", this );
  if( ! m_descend ) {
    fatal() << "Unable to retrieve ParticleDescendants tool "<< endreq;
    return StatusCode::FAILURE;
  }
 
  m_util = tool<ITaggingUtilsChecker> ( "TaggingUtilsChecker", this );
  if( ! m_util ) {
    fatal() << "Unable to retrieve TaggingUtilsChecker tool "<< endreq;
    return StatusCode::FAILURE;
  }
 
  return DaVinciAlgorithm::initialize() ;
}
//=============================================================================
StatusCode SingleBCandidateSelection_BuDpi::finalize() {
  return DaVinciAlgorithm::finalize();
}
//=============================================================================
SingleBCandidateSelection_BuDpi::~SingleBCandidateSelection_BuDpi() {};

