// Include files 
#include "SingleBCandidateSelection_BdJpsiKs.h"
// from LHCb core
#include "Event/ODIN.h"

#include "DecayTreeFitter/Fitter.h"
#include "LoKi/Particles36.h"
#include "LoKi/ParticleCuts.h"

//-----------------------------------------------------------------------------
// Implementation file for class : SingleBCandidateSelection_BdJpsiKs
//
// Author: Marco Musy
//-----------------------------------------------------------------------------

using namespace LHCb ;
using namespace Gaudi::Units;

using namespace LoKi::Cuts;


// Declaration of Factory
DECLARE_ALGORITHM_FACTORY( SingleBCandidateSelection_BdJpsiKs );

//=============================================================================
SingleBCandidateSelection_BdJpsiKs::SingleBCandidateSelection_BdJpsiKs(const std::string& name,
                                                                         ISvcLocator* pSvcLocator)
  : DaVinciAlgorithm ( name , pSvcLocator ),
    m_descend(0),
    m_util(0)
{
  declareProperty( "InputLocation",
                   m_inputLocation = "/Event/Dimuon/Phys/Bd2JpsiKsUnbiasedLine");
}

//=============================================================================
StatusCode SingleBCandidateSelection_BdJpsiKs::execute() {

  setFilterPassed( false );

  if ( msgLevel(MSG::DEBUG) )  debug() << "Getting particles saved in "<<m_inputLocation<< endmsg ;
  
  if(!exist<Particle::Container>(m_inputLocation) &&
     !exist<Particle::Selection>(m_inputLocation) ){
    if ( msgLevel(MSG::DEBUG) )    debug()<<"nosignal found in : "<< m_inputLocation<<endmsg;
    
    return StatusCode::SUCCESS; //unselected
  }
  
  const Particle* AXBS  = 0;
  const Particles* ptmp = get<Particles>( m_inputLocation );
  double minchi2B = 9999;
  for( Particles::const_iterator ip=ptmp->begin(); ip!=ptmp->end(); ip++){
    if ( msgLevel(MSG::DEBUG) )    debug()<<"signal part pt: "<< (*ip)->pt() << "  ID: "<< (*ip)->particleID().pid()<<endreq;

    if((*ip)->particleID().hasBottom()) {

      ////////////////////////////////////////////////////

      const Particle* Bd = (*ip);
      Particle::ConstVector parts = m_descend->descendants(Bd);

      const Particle* Ks = findID(310, parts);//find K0s
      const Particle* Jpsi = findID(443, parts);//find Jpsi
      const Particle* muon  = findID( 13, parts);//find mu
      const Particle* muonplus  = findID( -13, parts);//find mu+
      const Particle* pi_m  = findID(-211, parts);//find pion
      const Particle* pi_p  = findID(211, parts);//find pion

      if(!Ks)  return StatusCode::SUCCESS;
      if(!Jpsi)  return StatusCode::SUCCESS;
      if(!muon)   return StatusCode::SUCCESS;
      if(!muonplus)   return StatusCode::SUCCESS;
      if(!pi_m)   return StatusCode::SUCCESS;
      if(!pi_p)   return StatusCode::SUCCESS;
      

      //work out physical variables
      double pi_p_TRACK_Type    = pi_p->proto()->track()->type();
      double pi_p_TRACK_CHI2NDOF= pi_p->proto()->track()->chi2()/pi_p->proto()->track()->nDoF();
      double pi_p_MINIPCHI2     = get_MINIPCHI2(pi_p,0);
      double pi_p_P    = pi_p->p();
      double pi_p_M    = 139.57018;
      double pi_p_E    = sqrt(pi_p_P*pi_p_P + pi_p_M*pi_p_M);
      double pi_p_PT   = pi_p->pt();
      double pi_p_PIDK = pi_p->proto()->info(LHCb::ProtoParticle::CombDLLk,-1000);
      double pi_p_PIDp = pi_p->proto()->info(LHCb::ProtoParticle::CombDLLp,-1000);

      double pi_m_TRACK_Type    = pi_m->proto()->track()->type();
      double pi_m_TRACK_CHI2NDOF= pi_m->proto()->track()->chi2()/pi_m->proto()->track()->nDoF();
      double pi_m_MINIPCHI2     = get_MINIPCHI2(pi_m,0);
      double pi_m_P    = pi_m->p();
      double pi_m_M    = 139.57018;
      double pi_m_E    = sqrt(pi_m_P*pi_m_P + pi_m_M*pi_m_M);
      double pi_m_PT   = pi_m->pt();
      double pi_m_PIDK = pi_m->proto()->info(LHCb::ProtoParticle::CombDLLk,-1000);
      double pi_m_PIDp = pi_m->proto()->info(LHCb::ProtoParticle::CombDLLp,-1000);

      double Jpsi_MM = Jpsi->measuredMass();
      double Jpsi_MMerr = Jpsi->measuredMassErr();
      double Jpsi_PT = Jpsi->pt();
      double Jpsi_P = Jpsi->p();
      double Jpsi_E = sqrt(Jpsi_P*Jpsi_P + Jpsi_MM*Jpsi_MM);
      double Jpsi_ENDVERTEX_CHI2 = Jpsi->endVertex()->chi2();
      double Jpsi_ENDVERTEX_NDOF = Jpsi->endVertex()->nDoF();

      double Ks_MM = Ks->measuredMass();
      double Ks_PT = Ks->pt();
      double Ks_ENDVERTEX_CHI2 = Ks->endVertex()->chi2();
      double Ks_ENDVERTEX_NDOF = Ks->endVertex()->nDoF();

      double muon_TRACK_Type = muon->proto()->track()->type();
      double muon_PT    = muon->pt();
      double muon_PIDmu = muon->proto()->info(LHCb::ProtoParticle::CombDLLmu,-1000);
      double muon_MINIPCHI2 = get_MINIPCHI2(muon,0);
      double muon_TRACK_CHI2NDOF= muon->proto()->track()->chi2()/muon->proto()->track()->nDoF();

      double muonplus_TRACK_Type = muonplus->proto()->track()->type();
      double muonplus_PT    = muonplus->pt();
      double muonplus_PIDmu = muonplus->proto()->info(LHCb::ProtoParticle::CombDLLmu,-1000);
      double muonplus_MINIPCHI2 = get_MINIPCHI2(muon,0);
      double muonplus_TRACK_CHI2NDOF= muonplus->proto()->track()->chi2()/muonplus->proto()->track()->nDoF();

      double Bd_MM  = Bd->measuredMass();
      double Bd_PT  = Bd->pt();
      double Bd_ENDVERTEX_CHI2 = Bd->endVertex()->chi2();
      double Bd_ENDVERTEX_NDOF = Bd->endVertex()->nDoF();
      double Bd_ENDVERTEX_Z    = Bd->endVertex()->position().z();
      double Bd_MINIPCHI2 = get_MINIPCHI2(Bd,0);
      double Bd_MINIPCHI2NEXTBEST = get_MINIPCHI2(Bd,1);
      int nPV = (int) get_MINIPCHI2(Bd,2); // see the function below


 
  
      const VertexBase* aPV = bestPV( Bd );
      if( !aPV )return StatusCode::FAILURE;
      double Bd_OWNPV_Z = aPV->position().z();

      const Vertex* evtx = Bd->endVertex();
      if( !evtx ) return StatusCode::FAILURE;
      Gaudi::XYZVector A = Bd->momentum().Vect();
      Gaudi::XYZVector B = evtx->position() - aPV->position ();  
      double cosPFD = A.Dot( B ) / std::sqrt( A.Mag2()*B.Mag2() );
      double Bd_DIRA_OWNPV = cosPFD;

      if ( msgLevel(MSG::DEBUG) )      debug()<<"St DecayVertexFitter"<<endmsg;


      const DTF_CHI2NDOF fun = DTF_CHI2NDOF(true,"J/psi(1S)");
      const double DTF_chi2ndof = fun(Bd);

      const DTF_CTAU fun_tau = DTF_CTAU(0, true);
      const double DTF_tau = fun_tau(Bd);

      const DTF_CTAUERR fun_tau_err = DTF_CTAUERR(0, true);
      const double DTF_tau_err = fun_tau_err(Bd);

      
      const DTF_FUN fun2 = DTF_FUN(M, true,"J/psi(1S)");
      const double DTF_Bmass = fun2(Bd);
      if ( msgLevel(MSG::DEBUG) ){        
        debug()<<DTF_chi2ndof<<"   "<<endmsg;
        debug()<<DTF_Bmass<<"   "<<endmsg;
      }
      
      ////////////////////////////////////////////////////
      //      put here your selection cuts              //
      ////////////////////////////////////////////////////
      
      bool Strip12 = false;
      
      LHCb::ODIN* odin(0);
      
      if( exist<ODIN>( LHCb::ODINLocation::Default ) ){
        odin = get<ODIN>( LHCb::ODINLocation::Default );
      }
      
      if(
         // muon
         muon_PIDmu >  0. && muonplus_PIDmu > 0 // ok
         && muon_TRACK_CHI2NDOF < 3. && muonplus_TRACK_CHI2NDOF < 3. // ok
         && (muon_PT >500.*MeV || muonplus_PT >500.*MeV) // ok         
         && (Jpsi_ENDVERTEX_CHI2/Jpsi_ENDVERTEX_NDOF) < 16. //ok
         && fabs( Jpsi_MM - 3096.916) < 50. //ok         
         
         && pi_m_TRACK_CHI2NDOF < 3. //ok
         && pi_p_TRACK_CHI2NDOF < 3. //ok
         && pi_m_MINIPCHI2 > 6
         && pi_p_MINIPCHI2 > 6
         && pi_m_P > 2000.*MeV
         && pi_p_P > 2000.*MeV
         //&& pi_m_PIDK < 0. // ok
         //&& pi_p_PIDK < 0. // ok

         && Ks_PT > 1000  // ? 
         && fabs(Ks_MM - 497.614 )< 60. 
         && Ks_ENDVERTEX_CHI2/Ks_ENDVERTEX_NDOF < 20.

         // Bd
         && Bd_MM  > 5200
         && Bd_MM  < 5350.
         && Bd_ENDVERTEX_CHI2/Bd_ENDVERTEX_NDOF   < 10. // was 10.
         && Bd_MINIPCHI2 < 25. //ok
         //&& Bd_PT > 1000
         //&& DTF_chi2ndof < 5
         //&& ( nPV==1 || (nPV>1 && (Bd_MINIPCHI2NEXTBEST > 50 || Bd_MINIPCHI2NEXTBEST<0)))
         ) Strip12 = true ;

        
      if(!Strip12) continue;
         
         
         //double chi2 = (*ip)->endVertex()->chi2PerDoF();
      double chi2 = DTF_chi2ndof;
      if(minchi2B > chi2) {
        minchi2B = chi2;
        AXBS = (*ip);
      }
    }
        
    
  }
  
    
  if(!AXBS) return StatusCode::SUCCESS; //unselected


  //save to tes//////////////////////////////////////////////////
  Particle::ConstVector axdaughter(0);
  axdaughter.push_back(AXBS);
  if ( msgLevel(MSG::DEBUG) )  debug()<<"Going to save this B hypo to TES  "<<endreq;
  this->cloneAndMarkTrees(axdaughter);

/* // Commentato
  debug()<<"Going to save this B hypo to TES  "<<endreq;
  StatusCode sc1 = desktop()->cloneTrees(axdaughter);
  if (sc1.isFailure()) {
    warning() << "Unable to clone Tree to TES" << endreq;
    return StatusCode::SUCCESS;
  }
*/
//   StatusCode sc2 = desktop()->saveTrees(axdaughter);
//   if (sc2.isFailure()) {
//     warning() << "Unable to save Tree to TES" << endreq;
//     return StatusCode::SUCCESS;
//   }

  setFilterPassed( true );
  return StatusCode::SUCCESS;
}

//=============================================================================
const Particle* SingleBCandidateSelection_BdJpsiKs::findID(int id, 
                                                            Particle::ConstVector& v,
                                                            std::string opts ){
  const Particle* p=0;
  debug() <<"searching for signal id: "<<id<<endmsg;
  
  for( Particle::ConstVector::const_iterator ip=v.begin(); ip!=v.end(); ip++){
    if( abs(id)==13 && (*ip)->particleID().pid() == id ) {
      const Particle* mater = m_util->motherof(*ip, v);
      if(mater->particleID().abspid()!=443) continue;
      
      p = (*ip);
      break;
    }
    else if( abs(id)==211 && (*ip)->particleID().abspid() == abs(id) ) {
      const Particle* mater = m_util->motherof(*ip, v);
      if(mater->particleID().abspid()!=310) continue;
      
      p = (*ip);
      break;
    }
    else if( (*ip)->particleID().abspid() == id ) {
      p = (*ip);
      break;
    }
  }
  
  if(!p) {
    err()<<"particle not found id: "<<id<<endreq;
    return NULL;
  } 


  return p;

}

//=============================================================================
/* double SingleBCandidateSelection_BdJpsiKs::get_MINIPCHI2(const Particle* p, int opt){  
  double minchi2 = -1 ;
  double minchi2nextbest = -1;

  const RecVertex::Range PV = primaryVertices();
  if ( !PV.empty() ){
    for (RecVertex::Range::const_iterator pv = PV.begin(); pv!=PV.end(); ++pv){
      double ip, chi2;
      StatusCode test2 = distanceCalculator()->distance ( p, *pv, ip, chi2 );
      if( test2 ) {
        if ((chi2<minchi2) || (minchi2<0.)) {
          minchi2nextbest = minchi2 ;        
          minchi2 = chi2 ;     
        } else {
          if((chi2 < minchi2nextbest) || (minchi2nextbest < 0)) {
            minchi2nextbest = chi2;
          }
        }        
      }
    }
  }
  if(opt==0) return minchi2;
  else if(opt==1) return minchi2nextbest;
  else if(opt==2) return PV.size();
  else return -999;
  
}
*/


 double SingleBCandidateSelection_BdJpsiKs::get_MINIPCHI2(const Particle* p, int opt){  
  double minchi2 = -1 ;
  double minchi2nextbest = -1;

  const RecVertex::Range PV = primaryVertices();

  IPVReFitter* m_pvReFitter = tool<IPVReFitter>("AdaptivePVReFitter", this );
  

  if ( !PV.empty() ){
    for (RecVertex::Range::const_iterator pv = PV.begin(); pv!=PV.end(); ++pv){
      
      RecVertex newPV(**pv);
      // refit PV (remove B signal tracks)
      StatusCode scfit = m_pvReFitter->remove(p, &newPV);
      if(!scfit) {
        Warning("ReFitter fails!",StatusCode::SUCCESS,10).ignore();
        continue;
      }

      double chi2;      
      double ip;
      
      LHCb::VertexBase* newPVPtr = (LHCb::VertexBase*)&newPV;
      StatusCode test2 = distanceCalculator()->distance ( p, newPVPtr, ip, chi2 );
      if( test2 ) {
        if ((chi2<minchi2) || (minchi2<0.))
        { 
          minchi2nextbest = minchi2; 
          minchi2 = chi2 ;
        }
        else
        { 
          if((chi2 < minchi2nextbest) || (minchi2nextbest < 0))
          {            
            minchi2nextbest = chi2; 
          }
        }
      }
    }
  }
  if(opt==0) return minchi2;
  else if(opt==1) return minchi2nextbest;
  else if(opt==2) return PV.size();
  else return -999;
 }


//========================================================================
double SingleBCandidateSelection_BdJpsiKs::get_MIPDV(const Particle* p){
  
  double minip = -1;
  const RecVertex::Range PV = primaryVertices();
  if ( !PV.empty() ){
    for (RecVertex::Range::const_iterator pv = PV.begin(); pv!=PV.end(); ++pv){
      double ip, chi2;
      StatusCode test = distanceCalculator()->distance ( p, *pv, ip, chi2 );
      if( test ){  
        if( ip<minip || minip<0.) minip = ip ;//sara
      }			
    }	
  }  return minip; 
}

//=============================================================================
double SingleBCandidateSelection_BdJpsiKs::get_BPVVDCHI2(const Particle* B,
                                                          const Particle* P){
  const VertexBase* rV = getRelatedPV(B);

  double chi2 = 0 ;
  if ( 0==rV ){
    chi2 = -999. ;
  } else {
   // flight distance
    double dist = 0;
    StatusCode sc = distanceCalculator()->distance( rV, P->endVertex(), dist, chi2 );
    if (!sc) return -999.;
  }
  return chi2 ;
}


//=============================================================================
StatusCode SingleBCandidateSelection_BdJpsiKs::initialize() {

  m_descend = tool<IParticleDescendants> ( "ParticleDescendants", this );
  if( ! m_descend ) {
    fatal() << "Unable to retrieve ParticleDescendants tool "<< endreq;
    return StatusCode::FAILURE;
  }
 
  m_util = tool<ITaggingUtilsChecker> ( "TaggingUtilsChecker", this );
  if( ! m_util ) {
    fatal() << "Unable to retrieve TaggingUtilsChecker tool "<< endreq;
    return StatusCode::FAILURE;
  }
 
  return DaVinciAlgorithm::initialize() ;
}
//=============================================================================
StatusCode SingleBCandidateSelection_BdJpsiKs::finalize() {
  return DaVinciAlgorithm::finalize();
}
//=============================================================================
SingleBCandidateSelection_BdJpsiKs::~SingleBCandidateSelection_BdJpsiKs() {};

