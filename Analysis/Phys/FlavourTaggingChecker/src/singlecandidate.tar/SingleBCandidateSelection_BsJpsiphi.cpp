// Include files 
#include "SingleBCandidateSelection_BsJpsiphi.h"
// from LHCb core
#include "Event/ODIN.h"

#include "DecayTreeFitter/Fitter.h"
#include "LoKi/Particles36.h"
#include "LoKi/ParticleCuts.h"

//-----------------------------------------------------------------------------
// Implementation file for class : SingleBCandidateSelection_BsJpsiphi
//
// Author: Marco Musy
//-----------------------------------------------------------------------------

using namespace LHCb ;
using namespace Gaudi::Units;

using namespace LoKi::Cuts;


// Declaration of Factory
DECLARE_ALGORITHM_FACTORY( SingleBCandidateSelection_BsJpsiphi );

//=============================================================================
SingleBCandidateSelection_BsJpsiphi::SingleBCandidateSelection_BsJpsiphi(const std::string& name,
                                                                         ISvcLocator* pSvcLocator)
  : DVAlgorithm ( name , pSvcLocator ),
    m_descend(0),
    m_util(0)
{
  declareProperty( "InputLocation",
                   m_inputLocation = "/Event/Dimuon/Phys/Bs2JpsiphiUnbiasedLine");
}

//=============================================================================
StatusCode SingleBCandidateSelection_BsJpsiphi::execute() {

  setFilterPassed( false );

  debug() << "Getting particles saved in "<<m_inputLocation<< endmsg ;
  
  if(!exist<Particle::Container>(m_inputLocation) &&
     !exist<Particle::Selection>(m_inputLocation) ){
    debug()<<"nosignal found in : "<< m_inputLocation<<endmsg;
    
    return StatusCode::SUCCESS; //unselected
  }
  
  const Particle* AXBS  = 0;
  const Particles* ptmp = get<Particles>( m_inputLocation );
  double minchi2B = 9999;
  for( Particles::const_iterator ip=ptmp->begin(); ip!=ptmp->end(); ip++){
    debug()<<"signal part pt: "<< (*ip)->pt()
           << "  ID: "<< (*ip)->particleID().pid()<<endreq;

    if((*ip)->particleID().hasBottom()) {

      ////////////////////////////////////////////////////

      const Particle* Bs = (*ip);
      Particle::ConstVector parts = m_descend->descendants(Bs);

      const Particle* Phi = findID(333, parts);//find phi
      const Particle* Jpsi = findID(443, parts);//find Jpsi
      const Particle* muon  = findID( 13, parts);//find mu
      const Particle* muonplus  = findID( -13, parts);//find mu+
      const Particle* kaonplus  = findID(-321, parts);//find k+
      const Particle* kaonminus = findID(321, parts);//find k-

      if(!Phi)  return StatusCode::SUCCESS;
      if(!Jpsi)  return StatusCode::SUCCESS;
      if(!muon)   return StatusCode::SUCCESS;
      if(!muonplus)   return StatusCode::SUCCESS;
      if(!kaonplus)   return StatusCode::SUCCESS;
      if(!kaonminus)  return StatusCode::SUCCESS;
      



      //work out physical variables
      double kaonplus_TRACK_Type    = kaonplus->proto()->track()->type();
      double kaonplus_TRACK_CHI2NDOF= kaonplus->proto()->track()->chi2()/kaonplus->proto()->track()->nDoF();
      double kaonplus_MINIPCHI2     = get_MINIPCHI2(kaonplus,0);
      double kaonplus_P    = kaonplus->p();
      double kaonplus_M    = 493.677;
      double kaonplus_E    = sqrt(kaonplus_P*kaonplus_P + kaonplus_M*kaonplus_M);
      double kaonplus_PT   = kaonplus->pt();
      double kaonplus_PIDK = kaonplus->proto()->info(LHCb::ProtoParticle::CombDLLk,-1000);
      double kaonplus_PIDp = kaonplus->proto()->info(LHCb::ProtoParticle::CombDLLp,-1000);

      double kaonminus_TRACK_Type    = kaonminus->proto()->track()->type();
      double kaonminus_TRACK_CHI2NDOF= kaonminus->proto()->track()->chi2()/kaonminus->proto()->track()->nDoF();
      double kaonminus_MINIPCHI2     = get_MINIPCHI2(kaonminus,0);
      double kaonminus_P    = kaonminus->p();
      double kaonminus_M    = 493.677;
      double kaonminus_E    = sqrt(kaonminus_P*kaonminus_P + kaonminus_M*kaonminus_M);
      double kaonminus_PT   = kaonminus->pt();
      double kaonminus_PIDK = kaonminus->proto()->info(LHCb::ProtoParticle::CombDLLk,-1000);
      double kaonminus_PIDp = kaonminus->proto()->info(LHCb::ProtoParticle::CombDLLp,-1000);



      double Jpsi_MM = Jpsi->measuredMass();
      double Jpsi_MMerr = Jpsi->measuredMassErr();
      double Jpsi_PT = Jpsi->pt();
      double Jpsi_P = Jpsi->p();
      double Jpsi_E = sqrt(Jpsi_P*Jpsi_P + Jpsi_MM*Jpsi_MM);
      double Jpsi_ENDVERTEX_CHI2 = Jpsi->endVertex()->chi2();
      double Jpsi_ENDVERTEX_NDOF = Jpsi->endVertex()->nDoF();

      double Phi_MM = Phi->measuredMass();
      double Phi_PT = Phi->pt();
      double Phi_ENDVERTEX_CHI2 = Phi->endVertex()->chi2();
      double Phi_ENDVERTEX_NDOF = Phi->endVertex()->nDoF();

      double muon_TRACK_Type = muon->proto()->track()->type();
      double muon_PT    = muon->pt();
      double muon_PIDmu = muon->proto()->info(LHCb::ProtoParticle::CombDLLmu,-1000);
      double muon_MINIPCHI2 = get_MINIPCHI2(muon,0);
      double muon_TRACK_CHI2NDOF= muon->proto()->track()->chi2()/muon->proto()->track()->nDoF();

      double muonplus_TRACK_Type = muonplus->proto()->track()->type();
      double muonplus_PT    = muonplus->pt();
      double muonplus_PIDmu = muonplus->proto()->info(LHCb::ProtoParticle::CombDLLmu,-1000);
      double muonplus_MINIPCHI2 = get_MINIPCHI2(muon,0);
      double muonplus_TRACK_CHI2NDOF= muonplus->proto()->track()->chi2()/muonplus->proto()->track()->nDoF();

      double Bs_MM  = Bs->measuredMass();
      double Bs_PT  = Bs->pt();
      double Bs_ENDVERTEX_CHI2 = Bs->endVertex()->chi2();
      double Bs_ENDVERTEX_NDOF = Bs->endVertex()->nDoF();
      double Bs_ENDVERTEX_Z    = Bs->endVertex()->position().z();
      double Bs_MINIPCHI2 = get_MINIPCHI2(Bs,0);
      double Bs_MINIPCHI2NEXTBEST = get_MINIPCHI2(Bs,1);
      int nPV = (int) get_MINIPCHI2(Bs,2); // see the function below


 
  
      const VertexBase* aPV = bestPV( Bs );
      if( !aPV )return StatusCode::FAILURE;
      double Bs_OWNPV_Z = aPV->position().z();

      const Vertex* evtx = Bs->endVertex();
      if( !evtx ) return StatusCode::FAILURE;
      Gaudi::XYZVector A = Bs->momentum().Vect();
      Gaudi::XYZVector B = evtx->position() - aPV->position ();  
      double cosPFD = A.Dot( B ) / std::sqrt( A.Mag2()*B.Mag2() );
      double Bs_DIRA_OWNPV = cosPFD;

      debug()<<"Start DecayVertexFitter"<<endmsg;


      const DTF_CHI2NDOF fun = DTF_CHI2NDOF(true,"J/psi(1S)");
      const double DTF_chi2ndof = fun(Bs);

      const DTF_CTAU fun_tau = DTF_CTAU(0, true);
      const double DTF_tau = fun_tau(Bs);

      const DTF_CTAUERR fun_tau_err = DTF_CTAUERR(0, true);
      const double DTF_tau_err = fun_tau_err(Bs);

      
      const DTF_FUN fun2 = DTF_FUN(M, true,"J/psi(1S)");
      const double DTF_Bmass = fun2(Bs);

      debug()<<DTF_chi2ndof<<"   "<<endmsg;
      debug()<<DTF_Bmass<<"   "<<endmsg;

      ////////////////////////////////////////////////////
      //      put here your selection cuts              //
      ////////////////////////////////////////////////////

      bool Strip12 = false;

      LHCb::ODIN* odin(0);

      if( exist<ODIN>( LHCb::ODINLocation::Default ) ){
        odin = get<ODIN>( LHCb::ODINLocation::Default );
      }
      
      if(
         // muon
         muon_PIDmu >  0. && muonplus_PIDmu > 0 // ok
         && muon_TRACK_CHI2NDOF < 4. && muonplus_TRACK_CHI2NDOF < 4. // ok
         && (muon_PT >500.*MeV || muonplus_PT >500.*MeV) // ok
         //------??      && (Jpsi_ENDVERTEX_CHI2/Jpsi_ENDVERTEX_NDOF) < 11. //ok
         && abs( Jpsi_MM - 3096.916) < 60. //ok
         //&& abs( Jpsi_MM - 3096.916)/Jpsi_MMerr < 1.4*3

         && kaonplus_TRACK_CHI2NDOF < 4. //ok
         && kaonplus_PIDK > 0. // ok
         && kaonminus_TRACK_CHI2NDOF < 4. //ok
         && kaonminus_PIDK > 0. // ok
         

         && Phi_PT > 1000
         && abs(Phi_MM - 1019.46 )< 12.
         && Phi_ENDVERTEX_CHI2/Phi_ENDVERTEX_NDOF < 20.

         // Bs
         && Bs_MM  > 5200
         && Bs_MM  < 5550.
         && Bs_ENDVERTEX_CHI2/Bs_ENDVERTEX_NDOF   < 10. // was 10.
         && Bs_MINIPCHI2 < 25. //ok
         && Bs_PT > 1000

         && DTF_chi2ndof < 5
         && DTF_chi2ndof > 0
         && ( nPV==1 || (nPV>1 && (Bs_MINIPCHI2NEXTBEST > 50 || Bs_MINIPCHI2NEXTBEST<0)) )
         
         ) Strip12 = true ;

      if(!Strip12) continue;
      

      //double chi2 = (*ip)->endVertex()->chi2PerDoF();
      double chi2 = DTF_chi2ndof;
      if(minchi2B > chi2) {
        minchi2B = chi2;
        AXBS = (*ip);
      }
    }
    
  }
  /*
  //CPPM
  TCut cutMu = "min(muplus_PIDmu,muminus_PIDmu)>0&&max(muplus_TRACK_CHI2NDOF,muminus_TRACK_CHI2NDOF)<4&&min(muplus_PT,muminus_PT)>500";
  TCut cutK = "Kplus_PIDK>0&&Kplus_TRACK_CHI2NDOF<4&&Kminus_PIDK>0&&Kminus_TRACK_CHI2NDOF<4";
  TCut cutPhi = "phi_1020_PT>1000&&phi_1020_ENDVERTEX_CHI2/phi_1020_ENDVERTEX_NDOF<20";
  TCut cutB = "B_s0_LOKI_DTF_VCHI2NDOF<5&&B_s0_IPCHI2_OWNPV<25";
 
  std::cout << "Make the output ntuple " << std::endl;

  TCut cut0 = "B_s0_M>5200&&B_s0_M<5550";

  TTree* smalltree = decaytree->CopyTree( cutMu && cutJ && cutK && cutPhi && cutB && cut0 );


   */
  
    
  if(!AXBS) {
    debug()<<" No signal selected, SKIP event "<<endreq;
    return StatusCode::SUCCESS; //unselected
  }
  

  //save to tes//////////////////////////////////////////////////
  Particle::ConstVector axdaughter(0);
  axdaughter.push_back(AXBS);
  debug()<<"Going to save this B hypo to TES  "<<endreq;
  this->cloneAndMarkTrees(axdaughter);

/* // Commentato
  debug()<<"Going to save this B hypo to TES  "<<endreq;
  StatusCode sc1 = desktop()->cloneTrees(axdaughter);
  if (sc1.isFailure()) {
    warning() << "Unable to clone Tree to TES" << endreq;
    return StatusCode::SUCCESS;
  }
*/
//   StatusCode sc2 = desktop()->saveTrees(axdaughter);
//   if (sc2.isFailure()) {
//     warning() << "Unable to save Tree to TES" << endreq;
//     return StatusCode::SUCCESS;
//   }

  setFilterPassed( true );
  return StatusCode::SUCCESS;
}

//=============================================================================
const Particle* SingleBCandidateSelection_BsJpsiphi::findID(unsigned int id, 
                                                            Particle::ConstVector& v,
                                                            std::string opts ){
  const Particle* p=0;
  debug() <<"searching for signal id: "<<id<<endmsg;
  
  for( Particle::ConstVector::const_iterator ip=v.begin(); ip!=v.end(); ip++){
    if( abs(id)==13 && (*ip)->particleID().pid() == id ) {
      const Particle* mater = m_util->motherof(*ip, v);
      if(mater->particleID().abspid()!=443) continue;
      
      p = (*ip);
      break;
    }
    else if( ( abs(id) == 321) && (*ip)->particleID().abspid() == abs(id) ) {
      const Particle* mater = m_util->motherof(*ip, v);
      if(mater->particleID().abspid()!=333) continue;
      
      p = (*ip);
      break;
    }
    else if( (*ip)->particleID().abspid() == id ) {
      p = (*ip);
      break;
    }
  }
  
  if(!p) {
    err()<<"particle not found id: "<<id<<endreq;
    return NULL;
  } 


  return p;

}

//=============================================================================
/* double SingleBCandidateSelection_BsJpsiphi::get_MINIPCHI2(const Particle* p, int opt){  
  double minchi2 = -1 ;
  double minchi2nextbest = -1;

  const RecVertex::Range PV = primaryVertices();
  if ( !PV.empty() ){
    for (RecVertex::Range::const_iterator pv = PV.begin(); pv!=PV.end(); ++pv){
      double ip, chi2;
      StatusCode test2 = distanceCalculator()->distance ( p, *pv, ip, chi2 );
      if( test2 ) {
        if ((chi2<minchi2) || (minchi2<0.)) {
          minchi2nextbest = minchi2 ;        
          minchi2 = chi2 ;     
        } else {
          if((chi2 < minchi2nextbest) || (minchi2nextbest < 0)) {
            minchi2nextbest = chi2;
          }
        }        
      }
    }
  }
  if(opt==0) return minchi2;
  else if(opt==1) return minchi2nextbest;
  else if(opt==2) return PV.size();
  else return -999;
  
}
*/


 double SingleBCandidateSelection_BsJpsiphi::get_MINIPCHI2(const Particle* p, int opt){  
  double minchi2 = -1 ;
  double minchi2nextbest = -1;

  const RecVertex::Range PV = primaryVertices();

  IPVReFitter* m_pvReFitter = tool<IPVReFitter>("AdaptivePVReFitter", this );
  

  if ( !PV.empty() ){
    for (RecVertex::Range::const_iterator pv = PV.begin(); pv!=PV.end(); ++pv){
      
      RecVertex newPV(**pv);
      // refit PV (remove B signal tracks)
      StatusCode scfit = m_pvReFitter->remove(p, &newPV);
      if(!scfit) {
        Warning("ReFitter fails!",StatusCode::SUCCESS,10).ignore();
        continue;
      }

      double chi2;      
      double ip;
      
      LHCb::VertexBase* newPVPtr = (LHCb::VertexBase*)&newPV;
      StatusCode test2 = distanceCalculator()->distance ( p, newPVPtr, ip, chi2 );
      if( test2 ) {
        if ((chi2<minchi2) || (minchi2<0.))
        { 
          minchi2nextbest = minchi2; 
          minchi2 = chi2 ;
        }
        else
        { 
          if((chi2 < minchi2nextbest) || (minchi2nextbest < 0))
          {            
            minchi2nextbest = chi2; 
          }
        }
      }
    }
  }
  if(opt==0) return minchi2;
  else if(opt==1) return minchi2nextbest;
  else if(opt==2) return PV.size();
  else return -999;
 }


//========================================================================
double SingleBCandidateSelection_BsJpsiphi::get_MIPDV(const Particle* p){
  
  double minip = -1;
  const RecVertex::Range PV = primaryVertices();
  if ( !PV.empty() ){
    for (RecVertex::Range::const_iterator pv = PV.begin(); pv!=PV.end(); ++pv){
      double ip, chi2;
      StatusCode test = distanceCalculator()->distance ( p, *pv, ip, chi2 );
      if( test ){  
        if( ip<minip || minip<0.) minip = ip ;//sara
      }			
    }	
  }  return minip; 
}

//=============================================================================
double SingleBCandidateSelection_BsJpsiphi::get_BPVVDCHI2(const Particle* B,
                                                          const Particle* P){
  const VertexBase* rV = getRelatedPV(B);

  double chi2 = 0 ;
  if ( 0==rV ){
    chi2 = -999. ;
  } else {
   // flight distance
    double dist = 0;
    StatusCode sc = distanceCalculator()->distance( rV, P->endVertex(), dist, chi2 );
    if (!sc) return -999.;
  }
  return chi2 ;
}


//=============================================================================
StatusCode SingleBCandidateSelection_BsJpsiphi::initialize() {

  m_descend = tool<IParticleDescendants> ( "ParticleDescendants", this );
  if( ! m_descend ) {
    fatal() << "Unable to retrieve ParticleDescendants tool "<< endreq;
    return StatusCode::FAILURE;
  }
 
  m_util = tool<ITaggingUtilsChecker> ( "TaggingUtilsChecker", this );
  if( ! m_util ) {
    fatal() << "Unable to retrieve TaggingUtilsChecker tool "<< endreq;
    return StatusCode::FAILURE;
  }
 
  return DVAlgorithm::initialize() ;
}
//=============================================================================
StatusCode SingleBCandidateSelection_BsJpsiphi::finalize() {
  return DVAlgorithm::finalize();
}
//=============================================================================
SingleBCandidateSelection_BsJpsiphi::~SingleBCandidateSelection_BsJpsiphi() {};

