// Include files 
#include "SingleBCandidateSelection_DStarMuNu.h"
// from LHCb core
#include "Event/ODIN.h"
//local
#include "Kernel/IPVReFitter.h"

//-----------------------------------------------------------------------------
// Implementation file for class : SingleBCandidateSelection_DStarMuNu
//
// Author: Marco Musy
//-----------------------------------------------------------------------------

using namespace LHCb ;
using namespace Gaudi::Units;

// Declaration of Factory
DECLARE_ALGORITHM_FACTORY( SingleBCandidateSelection_DStarMuNu );

//=============================================================================
SingleBCandidateSelection_DStarMuNu::SingleBCandidateSelection_DStarMuNu(const std::string& name,
                                                                         ISvcLocator* pSvcLocator)
  : DVAlgorithm ( name , pSvcLocator ),
    m_descend(0),
    m_util(0)
{
  declareProperty( "InputLocation",
                   m_inputLocation = "/Event/Semileptonic/Phys/Bd2DstarMuNuLine");
}

//=============================================================================
StatusCode SingleBCandidateSelection_DStarMuNu::execute() {

  setFilterPassed( false );

  debug() << "Getting particles saved in "<<m_inputLocation<< endmsg ;//sara era debug
  
  if(!exist<Particle::Container>(m_inputLocation) &&
     !exist<Particle::Selection>(m_inputLocation) ){
    debug()<<"nosignal found in : "<< m_inputLocation<<endmsg;
    
    return StatusCode::SUCCESS; //unselected
  }
  
  const Particle* AXBS  = 0;
  const Particles* ptmp = get<Particles>( m_inputLocation );
  double minchi2B = 9999;
  int iBsave(-1000), iB(0);
  
  for( Particles::const_iterator ip=ptmp->begin(); ip!=ptmp->end(); ip++){
    debug()<<"signal part pt: "<< (*ip)->pt()
           << "  ID: "<< (*ip)->particleID().pid()<<endreq;

    if((*ip)->particleID().hasBottom()) {
      iB++;      

      debug()<<"signal part pt: "<< (*ip)->pt()
             << "  ID: "<< (*ip)->particleID().pid()<<" "<<"candidate "<<iB<<"/"<<ptmp->size()<<endreq;
      
      ////////////////////////////////////////////////////

      const Particle* Bd = (*ip);
      Particle::ConstVector parts = m_descend->descendants(Bd);

      const Particle* Dstar = findID(413, parts);//find D*
      const Particle* D0    = findID(421, parts);//find D0
      const Particle* muon  = findID( 13, parts);//find mu
      const Particle* kaon  = findID(321, parts);//find kaon
      const Particle* pion  = findID(211, parts, "fast");//find pion
      const Particle* slpion= findID(211, parts, "slow");//find slow pion

      if(Dstar && D0 && muon && kaon && pion && slpion ){
        
        //work out physical variables
        double kaon_TRACK_Type    = kaon->proto()->track()->type();
        double kaon_TRACK_CHI2NDOF= kaon->proto()->track()->chi2()/kaon->proto()->track()->nDoF();
        double kaon_MINIPCHI2     = get_MINIPCHI2(kaon);
        double kaon_P    = kaon->p();
        double kaon_PT   = kaon->pt();
        double kaon_PIDK = kaon->proto()->info(LHCb::ProtoParticle::CombDLLk,-1000);
        double kaon_TRACK_CloneDist = kaon->proto()->track()->info(LHCb::Track::CloneDist, -1.);//sara
        double kaon_ID = kaon->particleID().pid();//sara
        
        double pion_TRACK_Type    = pion->proto()->track()->type();
        double pion_TRACK_CHI2NDOF= pion->proto()->track()->chi2()/pion->proto()->track()->nDoF();
        double pion_MINIPCHI2     = get_MINIPCHI2(pion);
        double pion_P  = pion->p();
        double pion_PT = pion->pt();
        double pion_TRACK_CloneDist = pion->proto()->track()->info(LHCb::Track::CloneDist, -1.);//sara
        double pion_ID = pion->particleID().pid();//sara
        
        
        double D0_MM  = D0->measuredMass();
        double D0Mass = 1864.5;
        double D0_ENDVERTEX_CHI2 = D0->endVertex()->chi2();
        double D0_ENDVERTEX_NDOF = D0->endVertex()->nDoF();
        double D0_ENDVERTEX_Z    = D0->endVertex()->position().z();
        double D0_PT  = D0->pt();
        double D0_BPVVDCHI2 = get_BPVVDCHI2(Bd, D0); //marco
        double D0_ID = D0->particleID().pid();//sara
        double D0_MIPDV = get_MIPDV(D0); //sara
        
        double Dstar_MM = Dstar->measuredMass();
        double DstMass  = 2010.0;
        double Dstar_PT = Dstar->pt();
        double Dstar_ENDVERTEX_CHI2 = Dstar->endVertex()->chi2();
        double Dstar_ENDVERTEX_NDOF = Dstar->endVertex()->nDoF();
        double Dstar_ID = Dstar->particleID().pid();//sara
        
        double slpi_PT = slpion->pt();
        double slpi_TRACK_CHI2NDOF= slpion->proto()->track()->chi2()/slpion->proto()->track()->nDoF();
        double slpi_MIPDV = get_MIPDV(slpion); //sara
        
        
        double slpi_TRACK_CloneDist = slpion->proto()->track()->info(LHCb::Track::CloneDist, -1.);//sara
        double slpi_ID = slpion->particleID().pid();//sara
        
        double muon_TRACK_Type = muon->proto()->track()->type();
        double muon_PT    = muon->pt();
        //double muon_PIDmu = muon->proto()->info(LHCb::ProtoParticle::CombDLLk,-1000); //m.m
        double muon_PIDmu = muon->proto()->info(LHCb::ProtoParticle::CombDLLmu,-1000);//sara
        double muon_MINIPCHI2 = get_MINIPCHI2(muon);
        double muon_TRACK_CHI2NDOF= muon->proto()->track()->chi2()/muon->proto()->track()->nDoF();
        double muon_TRACK_CloneDist = muon->proto()->track()->info(LHCb::Track::CloneDist, -1.);//sara
        double muon_ID = muon->particleID().pid();//sara
        double muon_MIPDV = get_MIPDV(muon); //sara
        
        double Bd_MM  = Bd->measuredMass();
        double B0Mass = 5279.4;
        double Bd_ENDVERTEX_CHI2 = Bd->endVertex()->chi2();
        double Bd_ENDVERTEX_NDOF = Bd->endVertex()->nDoF();
        double Bd_ENDVERTEX_Z    = Bd->endVertex()->position().z();
        double Bd_MINIPNEXTBEST = get_MINIPNEXTBEST(Bd);//sara gennaio
        double Bd_MINIPCHI2NEXTBEST = get_MINIPCHI2NEXTBEST(Bd);//sara gennaio
        
        const VertexBase* aPV = bestPV( Bd );
        if( !aPV )return StatusCode::FAILURE;
        double Bd_OWNPV_Z = aPV->position().z();
        
        const Vertex* evtx = Bd->endVertex();
        if( !evtx ) return StatusCode::FAILURE;
        Gaudi::XYZVector A = Bd->momentum().Vect();
        Gaudi::XYZVector B = evtx->position() - aPV->position ();  
        double cosPFD = A.Dot( B ) / std::sqrt( A.Mag2()*B.Mag2() );
        double Bd_DIRA_OWNPV = cosPFD;
        
        ////////////////////////////////////////////////////
        //      put here your selection cuts              //
        ////////////////////////////////////////////////////
        
        bool Strip10 = false;
        
        //     LHCb::ODIN* odin(0);
        
        //       if( exist<ODIN>( LHCb::ODINLocation::Default ) ){
        //         odin = get<ODIN>( LHCb::ODINLocation::Default );
        //       }
        
        if(
           kaon_TRACK_Type == 3 && pion_TRACK_Type == 3 
           && kaon_TRACK_CHI2NDOF < 5.  //sara
           && pion_TRACK_CHI2NDOF < 5.  //sara
           && kaon_MINIPCHI2 > 4 && pion_MINIPCHI2 > 4  
           && kaon_P  > 2000. && pion_P  > 2000. 
           && kaon_PT  > 400. && pion_PT  > 400. //sara
           && kaon_PIDK > 0.//sara
           && kaon_TRACK_CloneDist ==-1. && pion_TRACK_CloneDist ==-1.//sara
           
           && Dstar_ID*muon_ID > 0 //RS
           //&& Dstar_ID*muon_ID < 0 //WS
           
           && D0_ID*kaon_ID <0 //sara
           
           // D0 
           //&& fabs (D0_MM  - D0Mass) < 200.
           && D0_ENDVERTEX_CHI2/D0_ENDVERTEX_NDOF< 10.
           && D0_PT  > 1800.  //sara
           //&& fabs (D0_MM  - D0Mass) < 40.
           && D0_BPVVDCHI2 > 50.//sara
           && D0_MIPDV>0.02 //sara
           
           // D* 
           && fabs (Dstar_MM  - DstMass) < 100. 
           && Dstar_PT  > 1250.                
           && Dstar_ENDVERTEX_CHI2/Dstar_ENDVERTEX_NDOF<10.//sara
           && fabs( Dstar_MM  - D0_MM) < 165.5//stripping ha gia' 160.
           
           // slow pion
           && slpi_PT  > 110. 
           && slpi_TRACK_CHI2NDOF < 5.
           && slpi_MIPDV  > 0.04 //sara
           && slpi_TRACK_CloneDist ==-1.//sara
           
           //------
           // muon
           // StdLooseMuons + cuts
           && muon_TRACK_Type == 3 
           && muon_PT > 800.  
           && muon_PIDmu >  -4.
           && muon_MINIPCHI2  > 4.
           && muon_TRACK_CHI2NDOF < 5.//sara
           && muon_TRACK_CloneDist ==-1.//sara
           && muon_MIPDV  > 0.05 //sara
           
           // B0
           && Bd_MM  - B0Mass > -2279.  
           && Bd_MM  - B0Mass < -59.
           &&  Bd_ENDVERTEX_CHI2/Bd_ENDVERTEX_NDOF   < 6.6 //sara
           &&  Bd_DIRA_OWNPV > 0.999      
           &&  Bd_ENDVERTEX_Z - Bd_OWNPV_Z> 0.5
           &&  D0_ENDVERTEX_Z - Bd_ENDVERTEX_Z > -2.5
           
           //&& Bd_MINIPCHI2NEXTBEST>50 //sara gennaio
           
           
           ) Strip10 = true ;

        if(!Strip10) continue;
        
        //if(Strip10)info()<<Bd_MM<<" "<<Dstar_MM-D0_MM<<endmsg;
        
        
        double chi2 = (*ip)->endVertex()->chi2PerDoF();
        if(minchi2B > chi2) {
          minchi2B = chi2;
          AXBS = (*ip);
          iBsave = iB;
        }
      }      
    }    
  }
  
    
  if(!AXBS) return StatusCode::SUCCESS; //unselected


  //save to tes//////////////////////////////////////////////////
  Particle::ConstVector axdaughter(0);
  axdaughter.push_back(AXBS);
  debug()<<"Going to save this B hypo to TES  candidate #"<<iBsave<<endreq; //sara era debug

  this->cloneAndMarkTrees(axdaughter);
  

  //commento SARA
  // StatusCode sc1 = desktop()->cloneTrees(axdaughter);

//   if (sc1.isFailure()) {
//     warning() << "Unable to clone Tree to TES" << endreq;
//     return StatusCode::SUCCESS;
//   }

  //fine commento SARA


//   StatusCode sc2 = desktop()->saveTrees(axdaughter);
//   if (sc2.isFailure()) {
//     warning() << "Unable to save Tree to TES" << endreq;
//     return StatusCode::SUCCESS;
//   }

  setFilterPassed( true );
  return StatusCode::SUCCESS;
}

//=============================================================================
const Particle* SingleBCandidateSelection_DStarMuNu::findID(unsigned int id, 
                                                            Particle::ConstVector& v,
                                                            std::string opts ){
  const Particle* p=0;
  debug() <<"searching for signal id: "<<id<<endmsg;
  
  for( Particle::ConstVector::const_iterator ip=v.begin(); ip!=v.end(); ip++){

    debug() <<"  signal contains id: "<<(*ip)->particleID().pid()<<endmsg;
    
    if((*ip)->particleID().abspid() == id) {

      if(id==211 && opts=="slow"){
        const Particle* mater = m_util->motherof(*ip, v);
        if(mater->particleID().abspid()!=413) continue;
      }
      if(id==211 && opts=="fast"){
        const Particle* mater = m_util->motherof(*ip, v);
        if(mater->particleID().abspid()==413) continue;
      }
      
      p = (*ip);
      break;
    }
  }
  if(!p) {
    err()<<"particle not found id: "<<id<<endreq;
    return NULL;
  } 

  return p;

}

//=============================================================================
double SingleBCandidateSelection_DStarMuNu::get_MINIPCHI2(const Particle* p){  
  double minchi2 = -1 ;
  
  const RecVertex::Range PV = primaryVertices();
  if ( !PV.empty() ){
    for (RecVertex::Range::const_iterator pv = PV.begin(); pv!=PV.end(); ++pv){
      double ip, chi2;
      
      //sara marzo 2011 from TupleToolGeometry (5 righe)
      RecVertex newPV(**pv);
      StatusCode scfit = m_pvReFitter->remove(p, &newPV);
      if(!scfit) { err()<<"ReFitter fails!"<<endreq; continue; }

      LHCb::VertexBase* newPVPtr = (LHCb::VertexBase*)&newPV; 
      StatusCode test2 = distanceCalculator()->distance ( p, newPVPtr, ip, chi2 );

      //StatusCode test2 = distanceCalculator()->distance ( p, *pv, ip, chi2 );
      if( test2 ) {
        if ((chi2<minchi2) || (minchi2<0.)) minchi2 = chi2 ;        
      }
    }
  }
  return minchi2;
}
//========================================================= SARA gennaio
double SingleBCandidateSelection_DStarMuNu::get_MINIPCHI2NEXTBEST(const Particle* p){  
  double minchi2 = -1 ;
  double minchi2nextbest = -1;//sara gennaio
  const RecVertex::Range PV = primaryVertices();
  if ( !PV.empty() ){
    for (RecVertex::Range::const_iterator pv = PV.begin(); pv!=PV.end(); ++pv){
      double ip, chi2;

      //sara marzo 2011 from TupleToolGeometry (5 righe)
      RecVertex newPV(**pv);
      StatusCode scfit = m_pvReFitter->remove(p, &newPV);
      if(!scfit) { err()<<"ReFitter fails!"<<endreq; continue; }

      LHCb::VertexBase* newPVPtr = (LHCb::VertexBase*)&newPV; 
      StatusCode test2 = distanceCalculator()->distance ( p, newPVPtr, ip, chi2 );


      //StatusCode test2 = distanceCalculator()->distance ( p, *pv, ip, chi2 );
      if( test2 ) {
        if ((chi2<minchi2) || (minchi2<0.)) 
        {
          minchi2nextbest = minchi2;
          minchi2 = chi2 ;       
        } 
        else
        {
          if((chi2 < minchi2nextbest) || (minchi2nextbest < 0)) 
          {
            minchi2nextbest = chi2;
          }
        }
      }
    }
  }
  return minchi2nextbest;
}
//========================================================================
double SingleBCandidateSelection_DStarMuNu::get_MIPDV(const Particle* p){
  
  double minip = -1;
  double ipminnextbest = -1;//sara gennaio
  const RecVertex::Range PV = primaryVertices();
  if ( !PV.empty() ){
    for (RecVertex::Range::const_iterator pv = PV.begin(); pv!=PV.end(); ++pv){
      double ip, chi2;

      //sara marzo 2011 from TupleToolGeometry (5 righe)
      RecVertex newPV(**pv);
      StatusCode scfit = m_pvReFitter->remove(p, &newPV);
      if(!scfit) { err()<<"ReFitter fails!"<<endreq; continue; }

      LHCb::VertexBase* newPVPtr = (LHCb::VertexBase*)&newPV; 
      StatusCode test = distanceCalculator()->distance ( p, newPVPtr, ip, chi2 );

      //StatusCode test = distanceCalculator()->distance ( p, *pv, ip, chi2 );
      if( test ){  
        if( ip<minip || minip<0.) minip = ip ;//sara
      }			
    }	
  } 
  return minip; 
}
//======================================================Sara gennaio
double SingleBCandidateSelection_DStarMuNu::get_MINIPNEXTBEST(const Particle* p){
  
  double minip = -1;
  double ipminnextbest = -1;//sara gennaio
  const RecVertex::Range PV = primaryVertices();
  if ( !PV.empty() ){
    for (RecVertex::Range::const_iterator pv = PV.begin(); pv!=PV.end(); ++pv){
      double ip, chi2;
      
      //sara marzo 2011 from TupleToolGeometry (5 righe)
      RecVertex newPV(**pv);
      StatusCode scfit = m_pvReFitter->remove(p, &newPV);
      if(!scfit) { err()<<"ReFitter fails!"<<endreq; continue; }

      LHCb::VertexBase* newPVPtr = (LHCb::VertexBase*)&newPV; 
      StatusCode test = distanceCalculator()->distance ( p, newPVPtr, ip, chi2 );


      //StatusCode test = distanceCalculator()->distance ( p, *pv, ip, chi2 );
      if( test ){  
        
        if ((ip<minip) || (minip<0.)) 
        {
          ipminnextbest = minip;
          minip = ip ;
        }
        else
        {
          if((ip < ipminnextbest) || (ipminnextbest < 0)) 
          {
            ipminnextbest = ip;
          }
        }
        
      }			
    }	
  } 
  return ipminnextbest; 
}

//=============================================================================
double SingleBCandidateSelection_DStarMuNu::get_BPVVDCHI2(const Particle* B,
                                                          const Particle* P){
  const VertexBase* rV = getRelatedPV(B);

  double chi2 = 0 ;
  if ( 0==rV ){
    chi2 = -999. ;
  } else {
   // flight distance
    double dist = 0;
    StatusCode sc = distanceCalculator()->distance( rV, P->endVertex(), dist, chi2 );
    if (!sc) return -999.;
  }
  return chi2 ;
}


//=============================================================================
StatusCode SingleBCandidateSelection_DStarMuNu::initialize() {

  m_descend = tool<IParticleDescendants> ( "ParticleDescendants", this );
  if( ! m_descend ) {
    fatal() << "Unable to retrieve ParticleDescendants tool "<< endreq;
    return StatusCode::FAILURE;
  }
 
  m_util = tool<ITaggingUtilsChecker> ( "TaggingUtilsChecker", this );
  if( ! m_util ) {
    fatal() << "Unable to retrieve TaggingUtilsChecker tool "<< endreq;
    return StatusCode::FAILURE;
  }
 
  //sara marzo 2011
  m_pvReFitter = tool<IPVReFitter>("AdaptivePVReFitter", this );
  if(! m_pvReFitter) {
    fatal() << "Unable to retrieve AdaptivePVReFitter" << endreq;
    return StatusCode::FAILURE;
  }


  return DVAlgorithm::initialize() ;
}
//=============================================================================
StatusCode SingleBCandidateSelection_DStarMuNu::finalize() {
  return DVAlgorithm::finalize();
}
//=============================================================================
SingleBCandidateSelection_DStarMuNu::~SingleBCandidateSelection_DStarMuNu() {};

