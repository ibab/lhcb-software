import sys
import os
debug = False
from Gaudi.Configuration import *
from ROOT import Long,Double,TMath,TH1F,TH2F,TFile,gROOT,TList
# from multiprocessing import Process, Queue, Pool
from array import array

from Configurables import LHCbApp, PhysConf
lhcbApp=LHCbApp()
import random
import time
ti = time.clock()

lhcbApp.DataType = "2010"
lhcbApp.Simulation = True

appConf = ApplicationMgr()
appConf.HistogramPersistency = "ROOT"

#HistogramPersistencySvc().OutputFile    = "triggerhistos.root"

from Configurables import GaudiSequencer,L0DUAlg,L0DUFromRawAlg
#from Configurables import RawEventDump, StoreExplorerAlg

from Configurables import DecodeRawEvent
DecodeRawEvent().DataOnDemand=True
DecodeRawEvent().OverrideInputs=0.0 #ensureeverything is taken from DAQ/RawEvent
importOptions( "$L0TCK/L0DUConfig.opts" )
from DAQSys import Decoders
from DAQSys.Decoders import DecoderDB as ddb
ApplicationMgr().TopAlg+=[ddb["L0DUFromRawAlg/L0DUFromRaw"].setup()]

# L0 configured by hand 
l0seq = GaudiSequencer("seqL0")
appConf.TopAlg += [ l0seq ]
l0decode = L0DUFromRawAlg('L0DUFromRaw')
l0decode.WriteProcData = True
l0decode.WriteOnTES    = False

#import EvtSel

from Configurables import DataOnDemandSvc, L0SelReportsMaker, L0DecReportsMaker
DataOnDemandSvc().AlgMap["HltLikeL0/DecReports"] = L0DecReportsMaker( OutputLevel = 999 )
DataOnDemandSvc().AlgMap["HltLikeL0/SelReports"] = L0SelReportsMaker( OutputLevel = 999 )
L0SelReportsMaker().InputL0DUReportLocation = "Trig/L0/L0DUReport"

# evh next 2 lines
from Configurables import L0Conf
L0Conf().EnableL0DecodingOnDemand=True
#

l0DU = L0DUAlg('L0DU')
l0DU.ProcessorDataLocations = ["Trig/L0/L0DUData"]
l0DU.L0DUReportLocation = "Trig/L0/L0DUReport"
l0DU.WriteBanks = False
l0DU.WriteOnTES   = True
l0DU.TCK = '0x1810'
l0seq.Members+=[ l0decode, l0DU ]

def _updateL0Config( L0TCK, singleL0Configuration ) :
    importOptions('$L0TCK/L0DUConfig.opts')
    from Configurables import L0DUConfigProvider
    orig =  L0DUConfigProvider('ToolSvc.L0DUConfig.TCK_'+L0TCK)
    if not singleL0Configuration : return orig
    del allConfigurables['ToolSvc.L0DUConfig']
    single = L0DUConfigProvider('ToolSvc.L0DUConfig')
    for p,v in orig.getValuedProperties().items() : setattr(single,p,v)
    single.TCK = L0TCK
    from Configurables import L0DUFromRawTool, L0DUFromRawAlg
    l0du   = L0DUFromRawAlg("L0DUFromRaw")
    l0du.addTool(L0DUFromRawTool,name = "L0DUFromRawTool")
    getattr( l0du, 'L0DUFromRawTool' ).L0DUConfigProviderType = 'L0DUConfigProvider'
    from Configurables import L0DUAlg
    L0DUAlg('L0DU').L0DUConfigProviderType = 'L0DUConfigProvider'
    return single

l0DUConfig = _updateL0Config( '0x1810', True )
l0DUConfig.Conditions = [
  [ "name=[Electron(Et)>36]"   , "data=[Electron(Et)]"  , "comparator=[>]" , "threshold=[200]"  ],
#  [ "name=[Photon(Et)>139]"    , "data=[Photon(Et)]"    , "comparator=[>]" , "threshold=[XPhoton,HighEtX]" ],
  [ "name=[Hadron(Et)>61]"     , "data=[Hadron(Et)]"    , "comparator=[>]" , "threshold=[110]"  ],
  [ "name=[Spd_Had(Mult)<0]"      , "data=[Spd(Mult)]"     , "comparator=[<]" , "threshold=[900]"   ],
  [ "name=[Spd_Mu(Mult)<0]"       , "data=[Spd(Mult)]"     , "comparator=[<]" , "threshold=[900]"   ],
  [ "name=[Spd_DiMu(Mult)<0]"       , "data=[Spd(Mult)]"     , "comparator=[<]" , "threshold=[900]"   ],
  [ "name=[Spd_Electron_Photon(Mult)<0]" , "data=[Spd(Mult)]"     , "comparator=[<]" , "threshold=[900]"   ],
  [ "name=[Muon1(Pt)>8]"       , "data=[Muon1(Pt)]"     , "comparator=[>]" , "threshold=[60]"   ],
  [ "name=[Muon12(Pt)>1050]"   , "data=[DiMuonProd(Pt1Pt2)]", "comparator=[>]" , "threshold=[1635]"  ]
]
l0DUConfig.Channels =[
  [ "name=[Electron]"       , "rate==[100.0]" , "conditions= [Electron(Et)>36]&& [Spd_Had(Mult)<0]"                 , "MASK=[001]" ],
  [ "name=[Photon]"         , "rate==[100.0]" , "conditions= [Electron(Et)>36] && [Spd_Had(Mult)<0]"                  , "MASK=[001]" ],
#  [ "name=[Photon]"         , "rate==[100.0]" , "conditions= [Photon(Et)>139] && [Spd_Electron_Photon(Mult)<0]"                  , "MASK=[001]" ],
  [ "name=[Hadron]"         , "rate==[100.0]" , "conditions= [Hadron(Et)>61]  && [Spd_Had(Mult)<0]"                     , "MASK=[001]" ],
  [ "name=[Muon]"           , "rate==[100.0]" , "conditions= [Muon1(Pt)>8]    && [Spd_Had(Mult)<0]"                      , "MASK=[001]" ],
  [ "name=[DiMuon]"         , "rate==[100.0]" , "conditions= [Muon12(Pt)>1050]&& [Spd_DiMu(Mult)<0]" ,   "MASK=[001]" ],
]

appConf = ApplicationMgr( OutputLevel = 999, AppName = 'L0')
EventSelector().PrintFreq  = 1000


NEVEN = 1000
#NEVEN = 10

#--- Initialization
#--- Dictionary between event types and locations in TES
#--- Physics selections used: location: [0]: evettyp, [1]: # tracks, [2]: bin number 
     
location= {
             30000000: ("minBias",0,1),
             11102003: ("SelB2HH",2,2),
             11114001: ("DC06SelBd2KstarMuMu",4,3),
             13144001: ("Bs2JpsiPhi",4,4),
             11124001: ("SelBd2eeKstar",4,5),
             13112001: ("PreselBs2MuMu",2,6),
             13774002: ("BsDsMuNu",2,7),
             12103035: ("Bplus2KKPi",3,8),
             12165106: ("Bplus2DK",3,9),
             13264021: ("Bs2Dspi",4,10),
             21263002: ("D2KKpi",3,11),
             11874004: ("BDMuNu",3,12),
             }


# trigger categories
# l0 triggers
l0names={}
l0triggers = ["L0.*Decision","L0.*MuonDecision","L0HadronDecision","L0ElectronDecision","L0PhotonDecision"]

#exclusive order for counting
tistostob=['-TOS_','-TIS_','-TOB_']
#in/exclusive dictionary counters:
Incl={}
Excl={}

evtyp=[]
sevtyp=[]
evtot=[]
evl0=[]
evl0Mu=[]
evl0Had=[]
evl0Ecal=[]
binnumber=[]


nB=[]
Bs=[]
lumisum=0
nrread=0


timei=[]
timef=[]
difftempo=[]
nminbias = 0


import GaudiPython

appMgr = GaudiPython.AppMgr()
sel    = appMgr.evtsel()



evt = appMgr.evtsvc()
hist  = appMgr.histsvc()


import linecache
parsetscycle=1
nbofparsets=10
INDEX=0

iterparsetInit = 3
iterparset= iterparsetInit
firstEvent=1
#print 'number of parameter sets=',nbofparsets,' next line ',linecache.getline('../output/triggerpar.data',2)

class MyAlg(GaudiPython.PyAlgorithm):
  def execute(self):
    #print 'inside MyAlg execute'
    global location,l0names,l0triggers,tistostob,Incl,Excl,evtyp,sevtyp,evtot,evl0,evl0Mu,evl0Had,evl0Ecal
    global binnumber,nB,Bs,lumisum,nrread,timei,timef,difftempo,nminbias,iterparset,firstEvent
    nrread=nrread+1
#    print 'nrread=',nrread
    TISTOS = appMgr.toolsvc().create("TriggerTisTos",interface="ITriggerTisTos")
    L0TISTOS = appMgr.toolsvc().create("L0TriggerTisTos",interface="ITriggerTisTos")
# for debugging 
    def TOSTISTOB(trigger):
#put result of tistostob in list: note order for exclusive selections!
      if (trigger[0:2] <> 'L0') : 
           tistos = TISTOS.triggerTisTos(trigger)
           #print TISTOS.analysisReportTrigger()
           ttt=[0,0,0]   #make list of tistostob, all 0: did not trigger
           if tistos.decision() :
               if tistos.tos() : ttt[0]=1
               if tistos.tis() : ttt[1]=1
               if ttt[0]+ttt[1]==0: ttt[2]=1
           return ttt
       # specialized L0 code
      else: 
           tistos = L0TISTOS.triggerTisTos(trigger)
           ttt=[0,0,0]  
           #if TISTOS.hltObjectSummaries().size() :
           if tistos.decision() :
               if tistos.tos() : ttt[0]=1
               if tistos.tis() : ttt[1]=1
               if ttt[0]+ttt[1]==0: ttt[2]=1
           return ttt 
	   
    # define a helper class:
    class irange(object):
      def __init__(self, b, e ):
        self.begin, self.end  = b, e
      def __iter__(self):
        it = self.begin
        while it != self.end:
          yield it.__deref__()
          it.__postinc__(1)
 

    def getSPD():
      L0DUReport = evt['Trig/L0/L0DUReport']
      L0DUConfig = L0DUReport.configuration()
      datas      = L0DUConfig.data()
      nSPD=-1
      for x in irange(datas.begin(),datas.end()):
        idata = x.second
        if idata.name()=='Spd(Mult)': nSPD=idata.value()
      return nSPD  

    def getHltCPU():
      #calculate average hlt2 time for this SPD multiplicity
      x=1.5*getSPD()
      time=0.25406E-02+x*0.57132E-04-x**2*0.14650E-06+x**3*0.22346E-09
      return time

    def TrackPenalty(event_type):
      fraction=spdmu16()/360.
      #eff_track=(1.-0.026*fraction)**location[event_type][1]
      ##eff_track=(1.)**location[event_type][1]
      eff_track=1
      return eff_track


    #------- Def Function to simulate the SPD distrit. for signals ---------
    def spdmu13():
       nrspdbins=        80
       xmispdbins=  0.000000
       xmaspdbins=  2000.000
       #numbers from intehrated SPDmult distribution (HRBDM1 in Hbook)
       spdprob=[ 0.0,
                 0.8474576E-03, 0.4237288E-02, 0.9322034E-02, 0.2881356E-01, 0.4322034E-01, 0.6016949E-01, 0.8220339E-01, 0.1127119    ,
                 0.1474576    , 0.1847458    , 0.2338983    , 0.2762712    , 0.3355932    , 0.3915254    , 0.4440678    , 0.4915254    ,
                 0.5423729    , 0.5864407    , 0.6355932    , 0.6745763    , 0.7194915    , 0.7584746    , 0.7881356    , 0.8186440    ,
                 0.8415254    , 0.8661017    , 0.8830509    , 0.9008474    , 0.9161017    , 0.9330509    , 0.9457627    , 0.9559322    ,
                 0.9627119    , 0.9711865    , 0.9745763    , 0.9822034    , 0.9864407    , 0.9898305    , 0.9915254    , 0.9932203    ,
                 0.9957627    , 0.9966102    , 0.9966202    , 0.9974576    , 0.9983051    , 0.9991525    , 1.0000001
                ]
       odin=evt['DAQ/ODIN']
       seed=odin.runNumber()+odin.eventNumber()
       random.seed(seed)
       r=random.random()
       spdhits=0.
       dspd=(xmaspdbins-xmispdbins)/nrspdbins
       for i in range(1,nrspdbins):
         if spdprob[i]>r:
           #interpolate
           s1=(i-1)*dspd
           fr=(r-spdprob[i-1])/(spdprob[i]-spdprob[i-1])
           spdhits=s1+fr*dspd
           break
         
       return spdhits


    def spdmu14():
       nrspdbins=        80
       xmispdbins=  0.000000
       xmaspdbins=  1200.000
       #numbers from integrated SPDmult distribution (HRNDM1 in Hbook)
       spdprob=[
        0.000000,0.000090,0.000726,0.002460,0.006199,0.012359,0.021146,0.033203,0.048770,0.067918,
        0.090212,0.115743,0.144349,0.175522,0.208583,0.243502,0.279885,0.317130,0.354920,0.393617,
        0.431031,0.468655,0.505319,0.540568,0.575275,0.608292,0.639710,0.669937,0.698191,0.724676,
        0.749621,0.772950,0.794298,0.814135,0.832596,0.849507,0.864964,0.879035,0.891964,0.903574,
        0.914128,0.923573,0.932376,0.940284,0.947418,0.953865,0.959423,0.964405,0.968893,0.972824,
        0.976367,0.979454,0.982273,0.984687,0.986893,0.988718,0.990368,0.991783,0.992979,0.994034,
        0.994874,0.995671,0.996298,0.996913,0.997405,0.997797,0.998169,0.998467,0.998737,0.998938,
        0.999122,0.999271,0.999389,0.999496,0.999588,0.999661,0.999717,0.999770,0.999820,1.000001
                ]
       odin=evt['DAQ/ODIN']
       seed=odin.runNumber()+odin.eventNumber()
       random.seed(seed)
       r=random.random()
       spdhits=0.
       dspd=(xmaspdbins-xmispdbins)/nrspdbins
       for i in range(1,nrspdbins):
         if spdprob[i]>r:
           #interpolate
           s1=(i-1)*dspd
           fr=(r-spdprob[i-1])/(spdprob[i]-spdprob[i-1])
           spdhits=s1+fr*dspd
           break
         
       return spdhits
    def spdmu16():
       nrspdbins=        80
       xmispdbins=  0.000000
       xmaspdbins=  1200.000
       #numbers from integrated SPDmult distribution (HRNDM1 in Hbook)
       spdprob=[
        0.000000,0.000070,0.000593,0.002037,0.005110,0.010250,0.017678,0.027974,0.041035,0.057203,
        0.076323,0.098758,0.123873,0.151237,0.180732,0.212090,0.245074,0.278980,0.313895,0.349253,
        0.384604,0.420118,0.455351,0.489455,0.523242,0.555860,0.587482,0.618219,0.647449,0.674963,
        0.701543,0.726193,0.749205,0.770886,0.791133,0.809970,0.827480,0.843834,0.859042,0.872902,
        0.885704,0.897304,0.907935,0.917698,0.926645,0.934705,0.942077,0.948652,0.954463,0.959825,
        0.964675,0.968952,0.972712,0.976165,0.979231,0.981941,0.984414,0.986532,0.988284,0.989964,
        0.991295,0.992571,0.993683,0.994665,0.995454,0.996151,0.996765,0.997283,0.997699,0.998064,
        0.998364,0.998622,0.998850,0.999032,0.999181,0.999292,0.999401,0.999504,0.999577,1.000001
                ]
       odin=evt['DAQ/ODIN']
       seed=odin.runNumber()+odin.eventNumber()
       random.seed(seed)
       r=random.random()
       spdhits=0.
       dspd=(xmaspdbins-xmispdbins)/nrspdbins
       for i in range(1,nrspdbins):
         if spdprob[i]>r:
           #interpolate
           s1=(i-1)*dspd
           fr=(r-spdprob[i-1])/(spdprob[i]-spdprob[i-1])
           spdhits=s1+fr*dspd
           break
         
       return spdhits

    def spdmu20():
       nrspdbins=        80
       xmispdbins=  0.000000
       xmaspdbins=  2000.000
       #numbers from intehrated SPDmult distribution (HRBDM1 in Hbook)
       spdprob=[ 0.0,
                 0.3804632E-03, 0.2187663E-02, 0.5897180E-02, 0.1241261E-01, 0.2282779E-01, 0.3490750E-01, 0.5183811E-01, 0.7295382E-01,
                 0.1008703    , 0.1336377    , 0.1696390    , 0.2055928    , 0.2477767    , 0.2940505    , 0.3402768    , 0.3881676    ,
                 0.4328245    , 0.4798117    , 0.5257526    , 0.5683645    , 0.6152090    , 0.6581063    , 0.6994340    , 0.7341513    ,
                 0.7666334    , 0.7971180    , 0.8232273    , 0.8474342    , 0.8695011    , 0.8896181    , 0.9049318    , 0.9189613    ,
                 0.9328958    , 0.9443097    , 0.9548200    , 0.9637133    , 0.9704666    , 0.9763162    , 0.9811195    , 0.9850668    ,
                 0.9875398    , 0.9902506    , 0.9922481    , 0.9938174    , 0.9950540    , 0.9965283    , 0.9975270    , 0.9980502    ,
                 0.9988111    , 0.9990964    , 0.9993817    , 0.9994293    , 0.9995244    , 0.9996195    , 0.9997622    , 0.9998097    ,
                 0.9998097    , 0.99981      , 0.9998573    , 0.9999049    , 1.0000001
                 ]
       odin=evt['DAQ/ODIN']
       seed=odin.runNumber()+odin.eventNumber()
       random.seed(seed)
       r=random.random()
       spdhits=0.
       dspd=(xmaspdbins-xmispdbins)/nrspdbins
       for i in range(1,nrspdbins):
         if spdprob[i]>r:
           #interpolate
           s1=(i-1)*dspd
           fr=(r-spdprob[i-1])/(spdprob[i]-spdprob[i-1])
           spdhits=s1+fr*dspd
           break
         
       return spdhits

    def spdmu24():
       nrspdbins=        80
       xmispdbins=  0.000000
       xmaspdbins=  2000.000
       #numbers from intehrated SPDmult distribution (HRBDM1 in Hbook)
       spdprob=[ 0.0,
                 0.2735230E-03, 0.8205689E-03, 0.3008753E-02, 0.7476295E-02, 0.1458789E-01, 0.2352298E-01, 0.3574033E-01, 0.5078410E-01,
                 0.6874544E-01, 0.9144785E-01, 0.1194384    , 0.1477024    , 0.1779723    , 0.2113421    , 0.2517323    , 0.2922137    ,
                 0.3329686    , 0.3758206    , 0.4180343    , 0.4651714    , 0.5114880    , 0.5535193    , 0.5940008    , 0.6317469    ,
                 0.6690372    , 0.7033188    , 0.7348651    , 0.7663202    , 0.7971371    , 0.8229395    , 0.8440008    , 0.8666120    ,
                 0.8869438    , 0.9067287    , 0.9222283    , 0.9352663    , 0.9462983    , 0.9561452    , 0.9648067    , 0.9697301    ,
                 0.9759300    , 0.9794858    , 0.9833151    , 0.9860503    , 0.9886032    , 0.9907914    , 0.9926149    , 0.9935266    ,
                 0.9947119    , 0.9956236    , 0.9968089    , 0.9972647    , 0.9976295    , 0.9981765    , 0.9986324    , 0.9989059    ,
                 0.9990882    , 0.9993618    , 0.9994529    , 0.9994530    , 0.9995441    , 0.9996353    , 0.9997265    , 0.9998177    ,
                 0.9999088    , 1.0000001
                 ]
       odin=evt['DAQ/ODIN']
       seed=odin.runNumber()+odin.eventNumber()
       random.seed(seed)
       r=random.random()
       spdhits=0.
       dspd=(xmaspdbins-xmispdbins)/nrspdbins
       for i in range(1,nrspdbins):
         if spdprob[i]>r:
           #interpolate
           s1=(i-1)*dspd
           fr=(r-spdprob[i-1])/(spdprob[i]-spdprob[i-1])
           spdhits=s1+fr*dspd
           break
         
       return spdhits

    def L0Muon1xMuon2Cut():
      L0DUReport = evt['Trig/L0/L0DUReport']
      L0DUConfig = L0DUReport.configuration()
      datas      = L0DUConfig.data()
      ptm1=0.
      ptm2=0.
      for x in irange(datas.begin(),datas.end()) :
       idata = x.second
       if idata.name()=='Muon1(Pt)': ptm1=idata.value()
       if idata.name()=='Muon2(Pt)': ptm2=idata.value()
      dimuon=0
      if ptm1*ptm2>1300.**2: dimuon=1
      return dimuon

    def Signal_L0SPDCut(nrread):
      #apply SPD cut a posteriori to L0-decision, return accept: (>0), reject(=0)
      #Use only for MC data.
      #decode L0-reports for the channels.
      L0DUReport = evt['Trig/L0/L0DUReport']
      L0_Accept=L0DUReport.decision()
      if L0_Accept>0:
        spddraw=spdmu16()
        #mask L0-dimuon with pt1xpt2 cut untill L0DU is allows this
        #L0DiMuon=L0DUReport.channelDecisionByName('DiMuon')*L0Muon1xMuon2Cut()
        L0DiMuon=L0DUReport.channelDecisionByName('DiMuon')
        L0Muon=L0DUReport.channelDecisionByName('Muon')
        L0Hadron=L0DUReport.channelDecisionByName('Hadron')
        L0Electron=L0DUReport.channelDecisionByName('Electron')
        L0Photon=L0DUReport.channelDecisionByName('Photon')
        L0ElectronHi=L0DUReport.channelDecisionByName('ElectronHi')
        L0PhotonHi=L0DUReport.channelDecisionByName('PhotonHi')

        #read spdcut values from file
        f=open(os.environ["OUTPUTDIR"]+'/SPDCut_values.data','r')
        fr=f.read()
        f.close()
        values=fr.splitlines()[0].split(',')
        SPDhCut=float(values[0])
        SPDmuCut=float(values[1])
        SPDmumuCut=float(values[2])
        SPDegCut=float(values[3])
        #print 'Signal_L0SPDCut',spddraw,' dimu,mu,h,e,g=',L0DiMuon,L0Muon,L0Hadron,L0Electron,L0Photon,L0ElectronHi,L0PhotonHi
        #print 'Signal_L0SPDCut cuts=',SPDmumuCut,SPDmuCut,SPDhCut,SPDegCut
        ###if spddraw>SPDmumuCut: L0DiMuon=0
        ###if spddraw>SPDmuCut: L0Muon=0
        ###if spddraw>SPDhCut: L0Hadron=0
        ###if spddraw>SPDegCut: L0Electron=0
        ###if spddraw>SPDegCut: L0Photon=0
        ###if spddraw>SPDegCut: L0ElectronHi=0
        ###if spddraw>SPDegCut: L0PhotonHi=0
        L0_Accept=L0DiMuon+L0Muon+L0Hadron+L0Electron+L0Photon+L0ElectronHi+L0PhotonHi

      return L0_Accept
 
    def Data_L0andPt1xPt2Cut(nrread):
     #mask L0-Dimuon trigger with new pt1xpt2
     #Use only for real data, i.e. does not apply SPD cut in addition.
     #decode L0-reports for the channels.
     L0DUReport = evt['Trig/L0/L0DUReport']
     L0_Accept=L0DUReport.decision()
     if L0_Accept>0:
       #mask L0-dimuon with pt1xpt2 cut untill L0DU is allows this
       #L0DiMuon=L0DUReport.channelDecisionByName('DiMuon')*L0Muon1xMuon2Cut()
       L0DiMuon=L0DUReport.channelDecisionByName('DiMuon')
       L0Muon=L0DUReport.channelDecisionByName('Muon')
       L0Hadron=L0DUReport.channelDecisionByName('Hadron')
       L0Electron=L0DUReport.channelDecisionByName('Electron')
       L0Photon=L0DUReport.channelDecisionByName('Photon')
       L0ElectronHi=L0DUReport.channelDecisionByName('ElectronHi')
       L0PhotonHi=L0DUReport.channelDecisionByName('PhotonHi')
       L0_Accept=L0DiMuon+L0Muon+L0Hadron+L0Electron+L0Photon+L0ElectronHi+L0PhotonHi

     return L0_Accept 


    # sel.FirstEvent = firstEvent
    # panorewind(appMgr,sel)

    # do this only on the first event
    if nrread==1:
       #re-initialize the arrays
       Incl={}
       Excl={}
       evtyp=[]
       sevtyp=[]
       evtot=[]
       evl0=[]
       evl0Mu=[]
       evl0Had=[]
       evl0Ecal=[]
       binnumber=[]
       nB=[]
       Bs=[]
       lumisum=0

       timei=[]
       timef=[]
       difftempo=[]
       nminbias = 0
       
       #read the new thresholds and set them
       print 'setting TCK properties'
       TCK_0x1810 = appMgr.tool('ToolSvc.L0DUConfig')
       TCK_0x1810.retrieveInterface()
       #import linecache
       
       linecache.clearcache()
       fr=linecache.getline(os.environ["OUTPUTDIR"]+'/triggerpar.data',iterparset)

       print 'fr ',fr
       triggerpar=fr.splitlines()[0].split(',')
       

       conds = [
         [ "name=[Electron(Et)>36]"   , "data=[Electron(Et)]"  , "comparator=[>]" , "threshold=["+triggerpar[1]+"]"  ],
#    [ "name=[Photon(Et)>139]"    , "data=[Photon(Et)]"    , "comparator=[>]" , "threshold=[XPhoton,HighEtX]" ],
         [ "name=[Hadron(Et)>61]"     , "data=[Hadron(Et)]"    , "comparator=[>]" , "threshold=["+triggerpar[2]+"]"  ],
         [ "name=[Spd_Had(Mult)<0]"      , "data=[Spd(Mult)]"     , "comparator=[<]" , "threshold=["+triggerpar[3]+"]"   ],
         [ "name=[Spd_Mu(Mult)<0]"       , "data=[Spd(Mult)]"     , "comparator=[<]" , "threshold=["+triggerpar[4]+"]"   ],
         [ "name=[Spd_DiMu(Mult)<0]"       , "data=[Spd(Mult)]"     , "comparator=[<]" , "threshold=["+triggerpar[5]+"]"   ],
         [ "name=[Spd_Electron_Photon(Mult)<0]" , "data=[Spd(Mult)]"     , "comparator=[<]" , "threshold=["+triggerpar[6]+"]"   ],
         [ "name=[Muon1(Pt)>8]"       , "data=[Muon1(Pt)]"     , "comparator=[>]" , "threshold=["+triggerpar[7]+"]"   ],
         [ "name=[Muon12(Pt)>1050]"   , "data=[DiMuonProd(Pt1Pt2)]", "comparator=[>]" , "threshold=["+triggerpar[8]+"]"  ]
       ]

       TCK_0x1810._ip.getProperty('Conditions').fromString(repr(conds))
 #      print 'conds = ', conds

    # this is where the original NEVEN loop was
    # we need to keep nrread (event number) each time MyAlg is called
    # and also the results of the counters
     
    # check L0
    L0DUReport = evt['Trig/L0/L0DUReport']
    if L0DUReport == None :
      nrread=nrread-1
      print 'No L0DUReport'
      return True # probably end of input

    L0DUConfig = L0DUReport.configuration()
    if (L0DUConfig == None):
      nrread=nrread-1
      print 'No L0DUReport configuration'
      return True


   ## select bb crossings only
    odin= evt['DAQ/ODIN']
    if odin.bunchCrossingType()!=odin.BeamCrossing:
      print 'Not a beamcrossing'
      return True

    if debug : 
     print evt['DAQ/ODIN']
     evt.dump()
     
    L0yesno=L0DUReport.decision()
    L0Muyesno=L0DUReport.triggerDecisionByName("L0Muon")
    L0Hadyesno=L0DUReport.triggerDecisionByName("L0Hcal")
    L0Ecalyesno=L0DUReport.triggerDecisionByName("L0Ecal")
    spdmult13 = spdmu13()
    spdmult14 = spdmu14()
    spdmult16 = spdmu16()
    spdmult20 = spdmu20()
    spdmult24 = spdmu24()
   

    # get event type
    test = None
    try:
       test =  evt['Gen/Header']
    except:
       test = None
    if test != None:
        event_type = evt['Gen/Header'].evType()
        #print 'Event type = ', event_type    
    else:

         #real data
          if nrread<5: print 'check event as if real data, file=',file
          if file.find('ReWeightedD2KPi')>-0.5:
            if nrread<5: print 'ReWeightedD2KPi in filename: runnr=',evt['DAQ/ODIN'].runNumber()
            if evt['DAQ/ODIN'].runNumber()==81680:
              #I checked that no D->KPi event has run 81680 :-)
              event_type = 30000000
            else:
              if nrread<5: print '*********This is real D2KPi data'
              event_type = 20000000
          elif file.find('d23h_NoBias_reweigh2')>-0.5:
              #print '*********This is real D23h data'
              event_type = 50000000
          elif file.find('tis-tau03-reweigh')>-0.5:
              print '*********This is real jpsi data'
              event_type = 60000000
          else:
            if nrread<5: print '******** This is NoBias data'
            event_type = 30000000


    if event_type not in evtyp:
      evtyp.append(event_type)
      sevtyp.append(str(event_type)+':')
      ity=evtyp.index(event_type)
      evtot.append(0)
      evl0.append(0)
      evl0Mu.append(0)
      evl0Had.append(0)
      evl0Ecal.append(0)
      nB.append(0)
      binnumber.append(0)
    #in/exclusive dictionary counters:
      for l0 in l0triggers:
        Incl[sevtyp[ity]+l0]=0

        for t in tistostob:
          Incl[sevtyp[ity]+l0+t]=0
          Excl[sevtyp[ity]+l0+t]=0
          m = l0triggers.index(l0)

# event type index
    ity=evtyp.index(event_type)
    evtot[ity]=evtot[ity]+1

# define the bin number to fill with the counters for each event type:
    binnumber[ity] = location[event_type][2]

    Bs = None
    if ((location[event_type][0] <> "minBias") and (location[event_type][0] <> "Hlt2HidValley")):
      Bs=evt["Phys/"+location[event_type][0]+"/Particles"]

    if (Bs <> None) :
     if (Bs.size() <> 0):
      L0TISTOS.setOfflineInput(Bs[0])
      nB[ity]=nB[ity]+1
     else:
      L0TISTOS.setOfflineInput()
# if L0 == true
    if event_type<>30000000 and event_type<>20000000 and event_type<>50000000 and event_type<>60000000:
      ##if nrread<5: print '********* spd testThis is real D23h data'
      #MC data, which needs an extra SPD-cut, and apply pt1xpt2
      L0yesno=Signal_L0SPDCut(nrread)
    else:
      #Real data, just apply pt1xpt2
      L0yesno=Data_L0andPt1xPt2Cut(nrread)
    
    if L0yesno<>0:#abcdef
      evl0[ity]=evl0[ity]+TrackPenalty(event_type)
      if L0Muyesno<>0:
        evl0Mu[ity]=evl0Mu[ity]+TrackPenalty(event_type)
      if L0Hadyesno<>0:
        evl0Had[ity]=evl0Had[ity]+TrackPenalty(event_type)
      if L0Ecalyesno<>0:
        evl0Ecal[ity]=evl0Ecal[ity]+TrackPenalty(event_type)
      #check Hlt

      veloraw = evt['Raw/Velo/Clusters']
      spdraw = evt['Raw/Spd/Digits']

      if event_type==30000000:
        nspd = getSPD()
        
        difft = getHltCPU()
        #print 'diferenca de tempo', difft
        difftempo.append(difft)
        nminbias += 1
          
# loop over l0 triggers
      for l0 in l0triggers:
        tttl0=TOSTISTOB(l0)                                 #get tostistob
#check which triggers are actually used for l0 "wildcard", accumulates over many events!
        nlist=TISTOS.triggerSelectionNames(l0)

        for name in nlist:
           if l0names.has_key(l0+':'+name)==0:
              l0names[l0+':'+name]=l0
              #print 'l0names=',l0names
        if 1 in tttl0:                                      #did it trigger
           Incl[sevtyp[ity]+l0]+=TrackPenalty(event_type)
           for i in range(len(tistostob)):                 #loop over tos/tis/tob
              Incl[sevtyp[ity]+l0+tistostob[i]]+=tttl0[i]      #inclusive counting
           iexl0=tttl0.index(1)
           Excl[sevtyp[ity]+l0+tistostob[iexl0]]+=1   #exclusive counting

    if event_type==30000000: lumisum=0.0765     
     

    return True


def panorewind(appMgr,sel):
     alg_list = appMgr.algorithms()
     alg_Enable = {}
     for a in alg_list:
       alg_Enable[a] = appMgr.algorithm(a).Enable
       appMgr.algorithm(a).Enable = False
     sel.rewind()
     for a in alg_list:
       appMgr.algorithm(a).Enable = alg_Enable[a]
     return 


files=[
  'root://castorlhcb.cern.ch//castor/cern.ch/user/e/evh/bwdivision/30000000/Beam6500GeV-RunII-MagUp-Nu1.5-25ns-Pythia8-30000000-L0-27360evts.xdigi',  
  'root://castorlhcb.cern.ch//castor/cern.ch/user/e/evh/bwdivision/11102003/Beam6500GeV-RunII-MagUp-Nu1.5-25ns-Pythia8-11102003-L0-28169evts.dst',
  #'root://castorlhcb.cern.ch//castor/cern.ch/user/e/evh/bwdivision/11114001/Beam6500GeV-RunII-MagUp-Nu1.5-25ns-Pythia8-11114001-L0-24149evts.dst',
  #'root://castorlhcb.cern.ch//castor/cern.ch/user/e/evh/bwdivision/13144001/Beam6500GeV-RunII-MagUp-Nu1.5-25ns-Pythia8-13144001-L0-21207evts.dst',  
  #'root://castorlhcb.cern.ch//castor/cern.ch/user/e/evh/bwdivision/11124001/Beam6500GeV-RunII-MagUp-Nu1.5-25ns-Pythia8-11124001-25245evts-L0.dst',
  'root://castorlhcb.cern.ch//castor/cern.ch/user/e/evh/bwdivision/13112001/Beam6500GeV-RunII-MagUp-Nu1.5-25ns-Pythia8-13112001-L0-31239evts.dst'
  #'root://castorlhcb.cern.ch//castor/cern.ch/user/e/evh/bwdivision/13774002/Beam6500GeV-RunII-MagUp-Nu1.5-25ns-Pythia8-13774002-L0-24723evts.dst',
  #'root://castorlhcb.cern.ch//castor/cern.ch/user/e/evh/bwdivision/12103035/Beam6500GeV-RunII-MagUp-Nu1.5-25ns-Pythia8-12103035-L0-24273evts.dst',
  #'root://castorlhcb.cern.ch//castor/cern.ch/user/e/evh/bwdivision/12165106/Beam6500GeV-RunII-MagUp-Nu1.5-25ns-Pythia8-12165106-L0-25101evts.dst',
  #'root://castorlhcb.cern.ch//castor/cern.ch/user/e/evh/bwdivision/13264021/Beam6500GeV-RunII-MagUp-Nu1.5-25ns-Pythia8-13264021-L0-21899evts.dst',
  #'root://castorlhcb.cern.ch//castor/cern.ch/user/e/evh/bwdivision/21263002/Beam6500GeV-RunII-MagUp-Nu1.5-25ns-Pythia8-21263002-L0-23568evts.dst',
  #'root://castorlhcb.cern.ch//castor/cern.ch/user/e/evh/bwdivision/11874004/Beam6500GeV-RunII-MagUp-Nu1.5-25ns-Pythia8-11874004-L0-22472evts.dst'
]


def SingleRun(fileNumber):
 
    global nbofparsets, INDEX, iterparsetInit, iterparset, NEVEN, appMgr, nrread,firstEvent, files 

    sel.open([files[fileNumber]])
    print files[fileNumber]


    appMgr.addAlgorithm(MyAlg())

    iterparset = iterparsetInit

    while iterparset<nbofparsets+3 :
      # loop over the parameter sets, first one: iterparset=3
      # put the parameterset number in the histogram name 
      sel.FirstEvent = firstEvent
      panorewind(appMgr,sel)
      nrread=0
      parsetnb=iterparset-2
      
	#-- book histos


      while nrread<NEVEN :
	appMgr.run(1)
    #    print 'result ',evtyp, sevtyp, evtot, evl0, evl0Mu, evl0Had, evl0Ecal,  Excl, Incl, lumisum, nB, difftempo, nminbias, binnumber

    #for evtyp, sevtyp, evtot, evl0, evl0Mu, evl0Had, evl0Ecal, Excl, Incl, lumisum, nB , difftempo, nminbias, binnumber :
      f=TFile(os.environ["OUTPUTDIR"]+'/bwdhistos_'+str(INDEX)+'_'+str(fileNumber)+'.root','update')
      for i in range(0,len(evtyp)):
	  if evtyp[i] == 30000000:
	    somatempo = 0
	    tperevent = 0
	    for j in difftempo:
	      somatempo = somatempo + j
	      if nminbias != 0:
		tperevent = somatempo*1000/nminbias # Time in ms
	      else:
		tperevent = 0
	    print 'Numero de minbias: ', nminbias
	    print 'Soma dos tempos: ', somatempo
	    print 'Tempo/Evento:', tperevent, '  '
	    tpereventHist=TH1F('tperevent-p'+str(parsetnb),'tperevent-p'+str(parsetnb), 14, 0., 15.)
	    tpereventHist.SetBinContent(binnumber[i],tperevent)
	    tpereventHist.Write()

    # print results for Minuit FCN:
    #print 'Tempo final: ', time.ctime()
    # trigger categories
    # l0 triggers
      l0names={}
      l0triggers = ["L0.*Decision","L0.*MuonDecision","L0HadronDecision","L0ElectronDecision","L0PhotonDecision"]
      tistostob=['-TOS_','-TIS_','-TOB_']
      for i in range(0,len(evtyp)):
#	  print 'Global Counters: eventType, evtot,nL0,nHLT'
	  print 'XResult-evtypX:',evtyp[i],evtot[i],evl0[i]/float(evtot[i]),evl0[i],'          '
	  print 'XResult-BWdivisionX:(l0Mu/l0Had/L0Ecal)',evl0Mu[i]/float(evtot[i]),evl0Had[i]/float(evtot[i]),evl0Ecal[i]/float(evtot[i]), evl0Mu[i],evl0Had[i],evl0Ecal[i],'          '
	  
	  Ntot=TH1F('Ntot-p'+str(parsetnb),'Ntot-p'+str(parsetnb), 14, 0., 15.)
	  L0count=TH1F('L0count-p'+str(parsetnb),'L0count-p'+str(parsetnb), 14, 0., 15.)
	  L0countmu=TH1F('L0countmu-p'+str(parsetnb),'L0countmu-p'+str(parsetnb), 14, 0., 15.)
	  L0counthad=TH1F('L0counthad-p'+str(parsetnb),'L0counthad-p'+str(parsetnb), 14, 0., 15.)
	  L0countele=TH1F('L0countele-p'+str(parsetnb),'L0countele-p'+str(parsetnb), 14, 0., 15.)
	  
          if evl0[i]==0:
              evl0[i]=1
	  print 'bin number = ', binnumber[i], '      '  
	  Ntot.SetBinContent(binnumber[i],evtot[i])
	  L0count.SetBinContent(binnumber[i],evl0[i])
	  L0countmu.SetBinContent(binnumber[i],evl0Mu[i])
	  L0counthad.SetBinContent(binnumber[i],evl0Had[i])
	  L0countele.SetBinContent(binnumber[i],evl0Ecal[i])
	  if 30000000 in evtyp:
	    i=evtyp.index(30000000)
	    print 'Average luminosity for mbias events=',lumisum,'          '
	    print 'XResult-RateX:(l0Mu/l0Had/L0Ecal)',evl0Mu[i]/float(evl0[i]),evl0Had[i]/float(evl0[i]),evl0Ecal[i]/float(evl0[i]), evl0Mu[i],evl0Had[i],evl0Ecal[i],'          '
	  #print 'histos = ', gROOT.GetList().ls()
	  Ntot.Write()
	  L0count.Write()
	  L0countmu.Write()
	  L0counthad.Write()
	  L0countele.Write()
	  #for h in gROOT.GetList():
	    #h.Write()
      f.Close()
      iterparset=iterparset+1

def MultiRun(worker_index, NParsetsWorkers,NEventWorkers,UsedChannels):
    
    global nbofparsets, iterparset, parsetscycle, iterparsetInit, INDEX, firstEvent, NEVEN
  
    linecache.clearcache()
    parsetscycle=int(linecache.getline(os.environ["OUTPUTDIR"]+'/triggerpar.data',1))
    nbofparsets=int(linecache.getline(os.environ["OUTPUTDIR"]+'/triggerpar.data',2))

    INDEX = worker_index

    eventIndex = INDEX%NEventWorkers
    # firstEvent = eventIndex*NEVEN + 1
    firstEvent = 1
    
    iparSetStartIndex = INDEX/NEventWorkers

    iparSetInit = iparSetStartIndex*nbofparsets/NParsetsWorkers
    iterparsetInit = 3 + iparSetInit
    nbofparsets = (iparSetStartIndex+1)*nbofparsets/NParsetsWorkers
    

    if os.path.exists(os.path.join(os.environ["OUTPUTDIR"],'bwdhistos_'+str(INDEX)+'_0.root')):	
      os.remove(os.path.join(os.environ["OUTPUTDIR"],'bwdhistos_'+str(INDEX)+'_0.root'))	
    if os.path.exists(os.path.join(os.environ["OUTPUTDIR"],'bwdhistos_'+str(INDEX)+'_1.root')):	
      os.remove(os.path.join(os.environ["OUTPUTDIR"],'bwdhistos_'+str(INDEX)+'_1.root'))	
    if os.path.exists(os.path.join(os.environ["OUTPUTDIR"],'bwdhistos_'+str(INDEX)+'_2.root')):	
      os.remove(os.path.join(os.environ["OUTPUTDIR"],'bwdhistos_'+str(INDEX)+'_2.root'))

    p=Pool(5)
    p.map(SingleRun, UsedChannels)

    if os.path.exists(os.path.join(os.environ["OUTPUTDIR"],'bwdhistosRes_ParSet'+str(iparSetStartIndex)+'_Event'+str(firstEvent)+'.root')): 
      os.remove(os.path.join(os.environ["OUTPUTDIR"],'bwdhistosRes_ParSet'+str(iparSetStartIndex)+'_Event'+str(firstEvent)+'.root'))
      
    gROOT.ProcessLine('.! hadd -f $OUTPUTDIR/bwdhistosRes_ParSet'+str(iparSetStartIndex)+'_Event'+str(firstEvent)+'.root $OUTPUTDIR/bwdhistos_'+str(INDEX)+'*')


      
      
